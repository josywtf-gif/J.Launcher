package com.fast.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

private fun col(s: String) = Color.parseColor(s)
private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

class MainActivity : Activity() {

    private class App(val pkg: String, val label: String, val ri: ResolveInfo)
    private class Theme(val name: String, val bg: IntArray, val accent: Int)

    private val themes = listOf(
        Theme("Полночь", intArrayOf(col("#0B1020"), col("#16213E"), col("#1F3A5F")), col("#4FA3FF")),
        Theme("Океан", intArrayOf(col("#032B43"), col("#136F63"), col("#1B9AAA")), col("#4DD0E1")),
        Theme("Закат", intArrayOf(col("#2B0F3A"), col("#8E2C5A"), col("#F2762E")), col("#FFB74D")),
        Theme("Лес", intArrayOf(col("#0B1F14"), col("#1E4D2B"), col("#3E7C3A")), col("#9CCC65")),
        Theme("Графит", intArrayOf(col("#101214"), col("#1C1F24"), col("#2A2F36")), col("#B0BEC5")),
        Theme("Неон", intArrayOf(col("#0A0014"), col("#2A0A4A"), col("#00324D")), col("#00E5FF")),
        Theme("Сакура", intArrayOf(col("#2A1020"), col("#6B2C4A"), col("#C06C84")), col("#FF8FB1")),
        Theme("Пустыня", intArrayOf(col("#2B1A0E"), col("#6B4423"), col("#C08A4A")), col("#FFC857"))
    )

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val iconCache = ConcurrentHashMap<String, Drawable>()
    private var apps: List<App> = emptyList()
    private var byPkg: Map<String, App> = emptyMap()
    private var dirty = true
    private var accent = 0
    private var layer = 0 // 0 главный, 1 все приложения, 2 настройки, 3 подраздел настроек

    private lateinit var wall: ImageView
    private lateinit var mainCol: LinearLayout
    private lateinit var favRow: LinearLayout
    private lateinit var allBtn: TextView
    private lateinit var appsLayer: FrameLayout
    private lateinit var grid: GridView
    private lateinit var appsAdapter: AppsAdapter
    private lateinit var settingsLayer: FrameLayout
    private lateinit var panel: LinearLayout

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { dirty = true }
    }

    // ================= жизненный цикл =================
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        accent = prefs.getInt("accent", themes[0].accent)
        buildUi()
        applyWallpaper()
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
    }

    override fun onResume() {
        super.onResume()
        if (dirty) { dirty = false; loadApps() }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); closeLayers() }
    override fun onDestroy() { unregisterReceiver(pkgReceiver); super.onDestroy() }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_SETTINGS) { showSettings(); return true }
        return super.onKeyDown(k, e)
    }

    override fun onBackPressed() {
        when (layer) {
            3 -> showSettings()
            1, 2 -> closeLayers()
            else -> {}
        }
    }

    // ================= интерфейс =================
    private fun buildUi() {
        val root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply { setBackgroundColor(0x55000000) }, FrameLayout.LayoutParams(-1, -1))

        mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(40), dp(56), dp(40))
            clipChildren = false; clipToPadding = false
        }
        Widgets.map["clock"]?.create(this, JSONObject().put("size", 72))?.let { mainCol.addView(it) }
        Widgets.map["date"]?.create(this, JSONObject().put("size", 22))?.let { mainCol.addView(it) }
        mainCol.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        mainCol.addView(label("Избранное"))
        favRow = LinearLayout(this).apply { clipChildren = false; clipToPadding = false; setPadding(0, dp(8), 0, dp(20)) }
        mainCol.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; clipChildren = false; clipToPadding = false
            addView(favRow)
        })
        val btns = LinearLayout(this)
        allBtn = btn("Все приложения") { showApps() }
        btns.addView(allBtn, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(16) })
        btns.addView(btn("Настройки") { showSettings() })
        mainCol.addView(btns)
        root.addView(mainCol, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Все приложения» ---
        appsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0xEE0B0F16.toInt()) }
        val colm = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(32), dp(56), dp(16))
        }
        colm.addView(TextView(this).apply {
            text = "Все приложения"; textSize = 26f; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(16))
        })
        appsAdapter = AppsAdapter()
        grid = GridView(this).apply {
            adapter = appsAdapter
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(12); horizontalSpacing = dp(12)
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isVerticalScrollBarEnabled = false
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
            setOnItemLongClickListener { _, _, pos, _ -> appMenu(apps[pos]); true }
        }
        colm.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        appsLayer.addView(colm, FrameLayout.LayoutParams(-1, -1))
        root.addView(appsLayer, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Настройки» ---
        settingsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0xAA000000.toInt()) }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(32), dp(28), dp(32), dp(28))
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(col("#1B2230")) }
        }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(panel) }
        settingsLayer.addView(sv, FrameLayout.LayoutParams(dp(560), -2, Gravity.CENTER))
        root.addView(settingsLayer, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        allBtn.requestFocus()
    }

    private fun closeLayers() {
        layer = 0
        appsLayer.visibility = View.GONE
        settingsLayer.visibility = View.GONE
        mainCol.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        defaultFocus()
    }

    private fun defaultFocus() {
        val f = if (favRow.childCount > 0 && favRow.getChildAt(0).isFocusable) favRow.getChildAt(0) else allBtn
        f.requestFocus()
    }

    // ================= приложения =================
    private fun loadApps() = io.execute {
        val pm = packageManager
        val out = LinkedHashMap<String, App>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName || out.containsKey(p)) continue
                out[p] = App(p, ri.loadLabel(pm).toString(), ri)
            }
        }
        val list = out.values.sortedBy { it.label.lowercase() }
        ui.post {
            apps = list; byPkg = list.associateBy { it.pkg }
            renderFavs(); appsAdapter.notifyDataSetChanged()
            if (layer == 0) defaultFocus()
        }
        list.forEach { if (!iconCache.containsKey(it.pkg)) iconCache[it.pkg] = it.ri.loadIcon(pm) }
    }

    private fun launch(a: App) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).setClassName(a.pkg, a.ri.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Не удалось запустить") }
    }

    private fun favs(): MutableList<String> =
        (prefs.getString("favs", DEFAULT_FAVS) ?: "").split("|").filter { it.isNotEmpty() }.toMutableList()

    private fun toggleFav(p: String) {
        val l = favs()
        if (!l.remove(p)) l.add(p)
        prefs.edit().putString("favs", l.joinToString("|")).apply()
        renderFavs()
    }

    private fun appMenu(a: App) {
        val isFav = favs().contains(a.pkg)
        val items = arrayOf(if (isFav) "Убрать из избранного" else "Добавить в избранное", "О приложении", "Удалить")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> toggleFav(a.pkg)
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                else -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }.show()
    }

    private fun renderFavs() {
        favRow.removeAllViews()
        val list = favs().mapNotNull { byPkg[it] }
        if (list.isEmpty()) {
            favRow.addView(TextView(this).apply {
                text = "Пусто. Откройте «Все приложения», зажмите OK на приложении и выберите «Добавить в избранное»."
                textSize = 15f; setTextColor(col("#8FA3B8")); setPadding(dp(4), dp(20), 0, dp(20))
            })
            return
        }
        list.forEach { favRow.addView(favTile(it), LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(12) }) }
    }

    private fun favTile(a: App): View {
        val t = prefs.getInt("tileDp", 96)
        val iv = ImageView(this)
        val tv = TextView(this).apply {
            text = a.label; textSize = 13f; setTextColor(Color.WHITE)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }
        bindIcon(a, iv)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true; isClickable = true
            setPadding(dp(10), dp(10), dp(10), dp(8))
            addView(iv, LinearLayout.LayoutParams(dp(t), dp(t)))
            addView(tv, LinearLayout.LayoutParams(dp(t), -2))
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.1f else 1f).scaleY(if (f) 1.1f else 1f).setDuration(90).start()
                v.background = if (f) GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(alpha(accent, 0x88)) } else null
            }
            setOnClickListener { launch(a) }
            setOnLongClickListener { appMenu(a); true }
        }
    }

    private fun bindIcon(a: App, iv: ImageView) {
        iv.tag = a.pkg
        val c = iconCache[a.pkg]
        if (c != null) { iv.setImageDrawable(c.constantState?.newDrawable() ?: c); return }
        iv.setImageDrawable(null)
        io.execute {
            val d = a.ri.loadIcon(packageManager)
            iconCache[a.pkg] = d
            ui.post { if (iv.tag == a.pkg) iv.setImageDrawable(d.constantState?.newDrawable() ?: d) }
        }
    }

    private fun showApps() {
        layer = 1
        settingsLayer.visibility = View.GONE; appsLayer.visibility = View.VISIBLE
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        val t = prefs.getInt("tileDp", 96)
        grid.numColumns = ((resources.displayMetrics.widthPixels - dp(120)) / dp(t + 40)).coerceAtLeast(3)
        grid.selector = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(alpha(accent, 0x88)) }
        grid.adapter = appsAdapter
        grid.requestFocus()
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int): Any = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val a = apps[p]
            val v = (cv ?: cell()) as LinearLayout
            (v.getChildAt(1) as TextView).text = a.label
            bindIcon(a, v.getChildAt(0) as ImageView)
            return v
        }
    }

    private fun cell(): LinearLayout {
        val t = prefs.getInt("tileDp", 96)
        val iv = ImageView(this)
        val tv = TextView(this).apply {
            textSize = 13f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(10), dp(6), dp(8))
            addView(iv, LinearLayout.LayoutParams(dp(t), dp(t)))
            addView(tv, LinearLayout.LayoutParams(dp(t), -2))
        }
    }

    // ================= настройки =================
    private fun openLayer2() {
        appsLayer.visibility = View.GONE; settingsLayer.visibility = View.VISIBLE
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        panel.removeAllViews()
    }

    private fun showSettings() {
        layer = 2; openLayer2()
        panelTitle("Настройки")
        val first = addBtn("Темы (палитры)") { showThemes() }
        addBtn("Обои") { showWallpapers() }
        addBtn("Цвет акцента") { showAccent() }
        lateinit var sizeBtn: TextView
        sizeBtn = addBtn("Размер иконок: " + prefs.getInt("tileDp", 96)) {
            val n = when (prefs.getInt("tileDp", 96)) {
                72 -> 96
                96 -> 120
                120 -> 144
                else -> 72
            }
            prefs.edit().putInt("tileDp", n).apply()
            sizeBtn.text = "Размер иконок: $n"
            renderFavs()
        }
        addBtn("Сбросить всё") { resetAll() }
        addBtn("Закрыть") { closeLayers() }
        first.requestFocus()
    }

    private fun showThemes() {
        layer = 3; openLayer2()
        panelTitle("Темы (палитры)")
        themes.forEach { t ->
            panel.addView(themeItem(t), LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(8) })
        }
        addBtn("Назад") { showSettings() }
        panel.getChildAt(1).requestFocus()
    }

    private fun showWallpapers() {
        layer = 3; openLayer2()
        panelTitle("Обои")
        val grads = themes.map { it.bg } + listOf(
            intArrayOf(col("#000000")), intArrayOf(col("#16181D")), intArrayOf(col("#2B1B3D"), col("#0B0F16"))
        )
        val views = grads.map { g -> swatch(g) { setGradient(g) } }
        addSwatches(views, 4, dp(96), dp(60))
        addBtn("Своя картинка (из файла)") { pickImage() }
        addBtn("Картинка по ссылке") { askUrl() }
        addBtn("Назад") { showSettings() }
        views[0].requestFocus()
    }

    private fun showAccent() {
        layer = 3; openLayer2()
        panelTitle("Цвет акцента")
        val prev = View(this).apply { setBackgroundColor(accent) }
        val colors = listOf("#3D8BFF", "#00BCD4", "#1DE9B6", "#4CAF50", "#C6FF00", "#FFD600",
            "#FF9100", "#FF5252", "#FF4081", "#E040FB", "#7C4DFF", "#FFFFFF").map { col(it) }
        val views = colors.map { c -> swatch(intArrayOf(c)) { setAccent(c); prev.setBackgroundColor(c) } }
        addSwatches(views, 6, dp(64), dp(64))
        panel.addView(label("Свой оттенок (влево / вправо)"))
        val hsv = FloatArray(3)
        Color.colorToHSV(accent, hsv)
        val sb = SeekBar(this).apply {
            max = 360; keyProgressIncrement = 8; progress = hsv[0].toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val c = Color.HSVToColor(floatArrayOf(p.toFloat(), 0.75f, 1f))
                        accent = c; prefs.edit().putInt("accent", c).apply(); prev.setBackgroundColor(c)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        panel.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })
        panel.addView(prev, LinearLayout.LayoutParams(-1, dp(8)).apply { bottomMargin = dp(16) })
        addBtn("Назад") { showSettings() }
        views[0].requestFocus()
    }

    private fun setAccent(c: Int) { accent = c; prefs.edit().putInt("accent", c).apply() }

    private fun setGradient(g: IntArray) {
        prefs.edit().putString("wp_type", "grad").putString("wp_c", g.joinToString(",")).apply()
        applyWallpaper()
    }

    private fun applyThemePreset(t: Theme) {
        accent = t.accent
        prefs.edit().putInt("accent", t.accent).putString("wp_type", "grad").putString("wp_c", t.bg.joinToString(",")).apply()
        applyWallpaper()
        toast("Тема: " + t.name)
    }

    private fun resetAll() {
        prefs.edit().clear().apply()
        File(filesDir, "wallpaper.jpg").delete()
        accent = themes[0].accent
        applyWallpaper(); renderFavs(); showSettings()
        toast("Сброшено")
    }

    // ================= обои =================
    private fun applyWallpaper() {
        if (prefs.getString("wp_type", "grad") == "image") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) {
                io.execute {
                    val bmp = BitmapFactory.decodeFile(f.path)
                    if (bmp != null) ui.post { wall.background = null; wall.setImageBitmap(bmp) }
                }
                return
            }
        }
        val c = (prefs.getString("wp_c", null) ?: themes[0].bg.joinToString(","))
            .split(",").mapNotNull { it.trim().toIntOrNull() }
        val one = c.firstOrNull() ?: Color.BLACK
        val arr = if (c.size >= 2) c.toIntArray() else intArrayOf(one, one)
        wall.setImageDrawable(null)
        wall.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, arr)
    }

    private fun pickImage() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 7)
        } catch (e: Exception) { toast("На этом ТВ нет выбора файлов — используйте ссылку") }
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (rc == 7 && res == RESULT_OK) io.execute {
            try { contentResolver.openInputStream(u)!!.use { saveWallpaper(it.readBytes()) } }
            catch (e: Exception) { ui.post { toast("Не удалось загрузить картинку") } }
        }
    }

    private fun askUrl() {
        val et = EditText(this).apply { hint = "https://..."; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Ссылка на картинку").setView(et)
            .setPositiveButton("Загрузить") { _, _ ->
                val u = et.text.toString().trim()
                toast("Загрузка…")
                io.execute {
                    try {
                        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 8000; c.readTimeout = 15000
                        saveWallpaper(c.inputStream.use { it.readBytes() })
                    } catch (e: Exception) { ui.post { toast("Не удалось загрузить") } }
                }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun saveWallpaper(b: ByteArray) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 1920) s *= 2
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            ?: throw IllegalStateException("bad image")
        File(filesDir, "wallpaper.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        prefs.edit().putString("wp_type", "image").apply()
        ui.post { applyWallpaper(); toast("Обои установлены") }
    }

    // ================= элементы интерфейса =================
    private fun panelTitle(t: String) {
        panel.addView(TextView(this).apply { text = t; textSize = 22f; setTextColor(Color.WHITE); setPadding(0, 0, 0, dp(16)) })
    }

    private fun addBtn(text: String, onClick: () -> Unit): TextView {
        val b = btn(text, onClick)
        panel.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        return b
    }

    private fun addSwatches(v: List<View>, per: Int, w: Int, h: Int) {
        v.chunked(per).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { r.addView(it, LinearLayout.LayoutParams(w, h).apply { rightMargin = dp(10); bottomMargin = dp(10) }) }
            panel.addView(r)
        }
    }

    private fun btnBg(f: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(14).toFloat(); setColor(if (f) accent else 0x33FFFFFF)
    }

    private fun btn(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(28), dp(14), dp(28), dp(14))
        isFocusable = true; isClickable = true
        background = btnBg(false)
        setOnFocusChangeListener { v, f ->
            v.background = btnBg(f)
            v.animate().scaleX(if (f) 1.05f else 1f).scaleY(if (f) 1.05f else 1f).setDuration(90).start()
        }
        setOnClickListener { onClick() }
    }

    private fun swatch(colors: IntArray, onClick: () -> Unit): View {
        val v = View(this)
        val cs = if (colors.size == 1) intArrayOf(colors[0], colors[0]) else colors
        fun bg(f: Boolean) = GradientDrawable(GradientDrawable.Orientation.TL_BR, cs).apply {
            cornerRadius = dp(14).toFloat(); setStroke(if (f) dp(4) else 0, Color.WHITE)
        }
        v.background = bg(false)
        v.isFocusable = true; v.isClickable = true
        v.setOnFocusChangeListener { _, f ->
            v.background = bg(f)
            v.animate().scaleX(if (f) 1.1f else 1f).scaleY(if (f) 1.1f else 1f).setDuration(90).start()
        }
        v.setOnClickListener { onClick() }
        return v
    }

    private fun rowBg(f: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(12).toFloat(); setColor(if (f) alpha(accent, 0xCC) else 0x22FFFFFF)
    }

    private fun themeItem(t: Theme): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isFocusable = true; isClickable = true
            setPadding(dp(12), 0, dp(12), 0)
        }
        row.background = rowBg(false)
        row.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, t.bg).apply { cornerRadius = dp(8).toFloat() }
        }, LinearLayout.LayoutParams(dp(96), dp(36)))
        row.addView(View(this).apply {
            background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(t.accent) }
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { leftMargin = dp(12) })
        row.addView(TextView(this).apply {
            text = t.name; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(16), 0, 0, 0)
        })
        row.setOnFocusChangeListener { v, f -> v.background = rowBg(f) }
        row.setOnClickListener { applyThemePreset(t) }
        return row
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 16f; setTextColor(col("#B8C7D9")); setPadding(dp(4), dp(8), 0, 0)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val DEFAULT_FAVS = "com.google.android.youtube.tv|org.xbmc.kodi|com.netflix.ninja"
    }
}
