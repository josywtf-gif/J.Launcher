package com.fast.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.ResolveInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

private fun col(s: String) = Color.parseColor(s)
private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

/** Цвет текста/иконки поверх акцентного цвета: тёмный на светлом, белый на тёмном */
private fun onAccent(c: Int): Int {
    val l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
    return if (l > 0.6) 0xFF111111.toInt() else Color.WHITE
}

class MainActivity : Activity() {

    private class App(val pkg: String, val label: String, val ri: ResolveInfo)
    private class Theme(val name: String, val bg: IntArray, val accent: Int)

    /** Кнопка-иконка: kind 0 = шестерёнка, 1 = сетка «все приложения» */
    private class IconBtn(c: Context, private val kind: Int, private val accentOf: () -> Int) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        init {
            isFocusable = true; isClickable = true
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.12f else 1f).scaleY(if (f) 1.12f else 1f).setDuration(110).start()
                v.invalidate()
            }
        }
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            p.style = Paint.Style.FILL
            p.color = if (isFocused) accentOf() else 0x40FFFFFF
            cv.drawRoundRect(0f, 0f, w, h, w * 0.32f, w * 0.32f, p)
            p.color = if (isFocused) onAccent(accentOf()) else Color.WHITE
            val cx = w / 2
            val cy = h / 2
            if (kind == 0) {
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = w * 0.10f
                cv.drawCircle(cx, cy, w * 0.20f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cs = Math.cos(a).toFloat()
                    val sn = Math.sin(a).toFloat()
                    cv.drawLine(cx + cs * w * 0.30f, cy + sn * w * 0.30f, cx + cs * w * 0.38f, cy + sn * w * 0.38f, p)
                }
            } else {
                val s = w * 0.15f
                val g = w * 0.07f
                val x0 = cx - (1.5f * s + g)
                val y0 = cy - (1.5f * s + g)
                for (ri in 0..2) {
                    for (ci in 0..2) {
                        val x = x0 + ci * (s + g)
                        val y = y0 + ri * (s + g)
                        cv.drawRoundRect(x, y, x + s, y + s, s / 3, s / 3, p)
                    }
                }
            }
        }
    }

    // Все темы тёмные, чтобы белый текст читался; акцент яркий
    private val themes = listOf(
        Theme("Полночь", intArrayOf(col("#070B16"), col("#0F1B33"), col("#1B3358")), col("#5AA9FF")),
        Theme("Океан", intArrayOf(col("#031A27"), col("#0A3B4A"), col("#12636E")), col("#3DD9E8")),
        Theme("Закат", intArrayOf(col("#1A0A24"), col("#4A1740"), col("#8A3A3A")), col("#FF9E57")),
        Theme("Лес", intArrayOf(col("#07140D"), col("#12301D"), col("#245A33")), col("#A5E36B")),
        Theme("Графит", intArrayOf(col("#0C0D0F"), col("#17191D"), col("#25282E")), col("#B8C4CE")),
        Theme("Неон", intArrayOf(col("#07000F"), col("#1D0A38"), col("#002B45")), col("#00E5FF")),
        Theme("Сакура", intArrayOf(col("#1C0B16"), col("#44213A"), col("#7A3B5C")), col("#FF8FB8")),
        Theme("Пустыня", intArrayOf(col("#1B1109"), col("#43301B"), col("#7A5A30")), col("#FFC857")),
        Theme("Индиго", intArrayOf(col("#0A0A24"), col("#1A1A4D"), col("#2B2B7A")), col("#9FA8FF")),
        Theme("Рубин", intArrayOf(col("#1A0508"), col("#4A0F1A"), col("#7C1D2E")), col("#FF6B7D")),
        Theme("Изумруд", intArrayOf(col("#03160F"), col("#06402F"), col("#0B6B4F")), col("#34E0A1")),
        Theme("Чёрный", intArrayOf(col("#000000"), col("#050505"), col("#0D0D0D")), col("#FFFFFF"))
    )

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val iconCache = ConcurrentHashMap<String, Drawable>()
    private val favTiles = HashMap<String, View>()
    private var apps: List<App> = emptyList()
    private var byPkg: Map<String, App> = emptyMap()
    private var dirty = true
    private var accent = 0
    private var layer = 0 // 0 главный, 1 все приложения, 2 настройки, 3 подраздел
    private var backTarget: () -> Unit = {}
    private var movePkg: String? = null

    private lateinit var wall: ImageView
    private lateinit var scrim: View
    private lateinit var mainCol: LinearLayout
    private lateinit var favGrid: LinearLayout
    private lateinit var appsIcon: IconBtn
    private lateinit var appsLayer: FrameLayout
    private lateinit var grid: GridView
    private lateinit var appsAdapter: AppsAdapter
    private lateinit var settingsLayer: FrameLayout
    private lateinit var panel: LinearLayout
    private var clockV: TextView? = null
    private var dateV: TextView? = null

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { dirty = true }
    }

    // ================= жизненный цикл =================
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        accent = prefs.getInt("accent", themes[0].accent)
        buildUi()
        applyWallpaper(); applyDim(); applyFavBg(); applyClockSize()
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
    }

    override fun onResume() {
        super.onResume()
        if (dirty) { dirty = false; loadApps() }
    }

    override fun onPause() {
        super.onPause()
        if (movePkg != null) { movePkg = null; renderFavs() }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); closeLayers() }
    override fun onDestroy() { unregisterReceiver(pkgReceiver); super.onDestroy() }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (movePkg != null) {
            val cols = prefs.getInt("favCols", 7)
            val step = when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> -1
                KeyEvent.KEYCODE_DPAD_RIGHT -> 1
                KeyEvent.KEYCODE_DPAD_UP -> -cols
                KeyEvent.KEYCODE_DPAD_DOWN -> cols
                else -> 0
            }
            val end = e.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || e.keyCode == KeyEvent.KEYCODE_ENTER ||
                e.keyCode == KeyEvent.KEYCODE_BACK
            if (step != 0 || end) {
                if (e.action == KeyEvent.ACTION_DOWN) {
                    if (step != 0) moveStep(step) else if (e.repeatCount == 0) endMove()
                }
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_SETTINGS) { showSettings(); return true }
        return super.onKeyDown(k, e)
    }

    override fun onBackPressed() {
        when (layer) {
            1, 2 -> closeLayers()
            3 -> backTarget()
            else -> {}
        }
    }

    // ================= каркас интерфейса =================
    private fun buildUi() {
        val root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, FrameLayout.LayoutParams(-1, -1))
        scrim = View(this)
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(40), dp(56), dp(32))
            clipChildren = false; clipToPadding = false
        }

        // верхняя строка: виджеты слева, иконки справа
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val widgets = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clockV = Widgets.map["clock"]?.create(this, JSONObject().put("size", 72)) as? TextView
        dateV = Widgets.map["date"]?.create(this, JSONObject().put("size", 22)) as? TextView
        clockV?.let { shadow(it); widgets.addView(it) }
        dateV?.let { shadow(it); widgets.addView(it) }
        top.addView(widgets, LinearLayout.LayoutParams(0, -2, 1f))
        appsIcon = IconBtn(this, 1) { accent }
        appsIcon.setOnClickListener { showApps() }
        top.addView(appsIcon, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14); topMargin = dp(8) })
        val gear = IconBtn(this, 0) { accent }
        gear.setOnClickListener { showSettings() }
        top.addView(gear, LinearLayout.LayoutParams(dp(56), dp(56)).apply { topMargin = dp(8) })
        mainCol.addView(top, LinearLayout.LayoutParams(-1, -2))

        // избранное по центру, фон подстраивается под количество значков
        favGrid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false; clipToPadding = false
            setPadding(dp(18), dp(14), dp(18), dp(14))
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            clipChildren = false; clipToPadding = false
            addView(favGrid, LinearLayout.LayoutParams(-2, -2))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true; isVerticalScrollBarEnabled = false
            clipChildren = false; clipToPadding = false
            addView(inner, ViewGroup.LayoutParams(-1, -1))
        }
        mainCol.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(mainCol, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Все приложения» ---
        appsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0xEE0B0F16.toInt()) }
        val colm = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(32), dp(56), dp(16))
        }
        colm.addView(TextView(this).apply {
            text = "Все приложения"; textSize = 26f; setTextColor(Color.WHITE); setPadding(dp(8), 0, 0, dp(16))
        })
        appsAdapter = AppsAdapter()
        grid = GridView(this).apply {
            adapter = appsAdapter
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(10); horizontalSpacing = dp(10)
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isVerticalScrollBarEnabled = false
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
            setOnItemLongClickListener { _, _, pos, _ -> appMenu(apps[pos]); true }
        }
        colm.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        appsLayer.addView(colm, FrameLayout.LayoutParams(-1, -1))
        root.addView(appsLayer, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Настройки» (справа, слева виден предпросмотр) ---
        settingsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0x55000000) }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(24))
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(col("#171D29")) }
        }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(panel) }
        settingsLayer.addView(sv, FrameLayout.LayoutParams(dp(520), -2, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(40); topMargin = dp(24); bottomMargin = dp(24)
        })
        root.addView(settingsLayer, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        appsIcon.requestFocus()
    }

    private fun shadow(t: TextView) = t.setShadowLayer(5f, 0f, 2f, 0xCC000000.toInt())

    private fun fadeIn(v: View) {
        if (v.visibility != View.VISIBLE) {
            v.alpha = 0f; v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(170).start()
        }
    }

    private fun closeLayers() {
        layer = 0
        appsLayer.visibility = View.GONE
        settingsLayer.visibility = View.GONE
        mainCol.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        defaultFocus()
    }

    private fun defaultFocus() {
        val row = favGrid.getChildAt(0) as? ViewGroup
        val t = row?.getChildAt(0)
        (if (t != null && t.isFocusable) t else appsIcon).requestFocus()
    }

    private fun applyDim() {
        val d = prefs.getInt("dim", 40) * 255 / 100
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(alpha(Color.BLACK, (d + 30).coerceAtMost(255)), alpha(Color.BLACK, d), alpha(Color.BLACK, (d + 50).coerceAtMost(255)))
        )
    }

    private fun applyFavBg() {
        val a = prefs.getInt("favOp", 35) * 255 / 100
        favGrid.background = GradientDrawable().apply {
            cornerRadius = dp(26).toFloat()
            setColor(alpha(prefs.getInt("favBg", Color.BLACK), a))
        }
    }

    private fun applyClockSize() {
        val k = prefs.getInt("clkPct", 100) / 100f
        clockV?.textSize = 72f * k
        dateV?.textSize = 22f * k
    }

    private fun ts(base: Float) = base * prefs.getInt("txtPct", 100) / 100f

    // ================= приложения =================
    private fun loadApps() = io.execute {
        val pm = packageManager
        val out = LinkedHashMap<String, App>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName || out.containsKey(p)) continue
                out[p] = App(p, ri.loadLabel(pm).toString(), ri)
            }
        }
        val list = out.values.sortedBy { it.label.lowercase() }
        ui.post {
            apps = list; byPkg = list.associateBy { it.pkg }
            renderFavs(); appsAdapter.notifyDataSetChanged()
            if (layer == 0) defaultFocus()
        }
        list.forEach { if (!iconCache.containsKey(it.pkg)) iconCache[it.pkg] = it.ri.loadIcon(pm) }
    }

    private fun launch(a: App) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).setClassName(a.pkg, a.ri.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Не удалось запустить") }
    }

    private fun favs(): MutableList<String> =
        (prefs.getString("favs", DEFAULT_FAVS) ?: "").split("|").filter { it.isNotEmpty() }.toMutableList()

    private fun toggleFav(p: String) {
        val l = favs()
        if (!l.remove(p)) l.add(p)
        prefs.edit().putString("favs", l.joinToString("|")).apply()
        renderFavs()
    }

    private fun appMenu(a: App) {
        val isFav = favs().contains(a.pkg)
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (isFav) { items.add("Переместить в избранном"); acts.add { startMove(a.pkg) } }
        items.add(if (isFav) "Убрать из избранного" else "Добавить в избранное"); acts.add { toggleFav(a.pkg) }
        items.add("О приложении")
        acts.add { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        items.add("Удалить")
        acts.add { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        AlertDialog.Builder(this).setTitle(a.label).setItems(items.toTypedArray()) { _, w -> acts[w]() }.show()
    }

    // ----- значки: красивая форма -----
    private fun iconRadius(size: Int): Float = when (prefs.getInt("shape", 0)) {
        0 -> size * 0.22f
        1 -> size / 2f
        else -> size * 0.06f
    }

    private fun styleIcon(iv: ImageView, size: Int) {
        val r = iconRadius(size)
        iv.background = GradientDrawable().apply { cornerRadius = r; setColor(0x26FFFFFF) }
        val pad = (size * 0.05f).toInt()
        iv.setPadding(pad, pad, pad, pad)
        iv.clipToOutline = true
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
        }
    }

    private fun labelView(text: String) = TextView(this).apply {
        this.text = text; textSize = ts(13f); setTextColor(Color.WHITE)
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        setShadowLayer(4f, 0f, 2f, 0xCC000000.toInt())
    }

    // ----- избранное: сетка -----
    private fun renderFavs() {
        favGrid.removeAllViews(); favTiles.clear()
        val rows = prefs.getInt("favRows", 1)
        val cols = prefs.getInt("favCols", 7)
        val list = favs().mapNotNull { byPkg[it] }.take(rows * cols)
        if (list.isEmpty()) {
            favGrid.addView(TextView(this).apply {
                text = "Избранное пусто. Откройте «Все приложения» (значок сетки справа вверху), зажмите OK на приложении и выберите «Добавить в избранное»."
                textSize = ts(15f); setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 2f, 0xCC000000.toInt())
                setPadding(dp(8), dp(12), dp(8), dp(12))
                maxWidth = resources.displayMetrics.widthPixels / 2
            })
            return
        }
        val avail = resources.displayMetrics.widthPixels - dp(112) - dp(36)
        val icon = minOf(dp(prefs.getInt("tileDp", 96)), avail / cols - dp(40)).coerceAtLeast(dp(32))
        list.chunked(cols).forEach { chunk ->
            val r = LinearLayout(this).apply { clipChildren = false; clipToPadding = false }
            chunk.forEach { r.addView(favTile(it, icon), LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(4); rightMargin = dp(4) }) }
            favGrid.addView(r, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        }
    }

    private fun tileBg(pkg: String, f: Boolean): Drawable? {
        val r = dp(18).toFloat()
        if (pkg == movePkg) return GradientDrawable().apply { cornerRadius = r; setColor(alpha(accent, 0x66)); setStroke(dp(3), Color.WHITE) }
        if (f) return GradientDrawable().apply { cornerRadius = r; setColor(0x26FFFFFF); setStroke(dp(3), accent) }
        return null
    }

    private fun favTile(a: App, icon: Int): View {
        val iv = ImageView(this)
        styleIcon(iv, icon)
        bindIcon(a, iv)
        val tv = labelView(a.label)
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true; isClickable = true
            tag = a.pkg
            setPadding(dp(8), dp(10), dp(8), dp(8))
            addView(iv, LinearLayout.LayoutParams(icon, icon))
            addView(tv, LinearLayout.LayoutParams(icon + dp(16), -2).apply { topMargin = dp(6) })
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.08f else 1f).scaleY(if (f) 1.08f else 1f).setDuration(110).start()
                v.background = tileBg(a.pkg, f)
            }
            setOnClickListener { launch(a) }
            setOnLongClickListener { appMenu(a); true }
        }
        t.background = tileBg(a.pkg, false)
        favTiles[a.pkg] = t
        return t
    }

    // ----- избранное: перемещение -----
    private fun startMove(pkg: String) {
        closeLayers()
        if (!favTiles.containsKey(pkg)) { toast("Приложение не помещается в сетку избранного"); return }
        movePkg = pkg
        renderFavs()
        favTiles[pkg]?.requestFocus()
        toast("Стрелки — переместить, OK — готово")
    }

    private fun moveStep(step: Int) {
        val p = movePkg ?: return
        val all = favs()
        val vis = all.filter { byPkg.containsKey(it) }.toMutableList()
        val rest = all.filter { !byPkg.containsKey(it) }
        val i = vis.indexOf(p)
        if (i < 0) return
        val cap = minOf(vis.size, prefs.getInt("favRows", 1) * prefs.getInt("favCols", 7))
        val j = i + step
        if (j < 0 || j >= cap) return
        vis[i] = vis[j]; vis[j] = p
        prefs.edit().putString("favs", (vis + rest).joinToString("|")).apply()
        renderFavs()
        favTiles[p]?.requestFocus()
    }

    private fun endMove() {
        val p = movePkg
        movePkg = null
        renderFavs()
        if (p != null) favTiles[p]?.requestFocus()
    }

    // ----- все приложения -----
    private fun bindIcon(a: App, iv: ImageView) {
        iv.tag = a.pkg
        val c = iconCache[a.pkg]
        if (c != null) { iv.setImageDrawable(c.constantState?.newDrawable() ?: c); return }
        iv.setImageDrawable(null)
        io.execute {
            val d = a.ri.loadIcon(packageManager)
            iconCache[a.pkg] = d
            ui.post { if (iv.tag == a.pkg) iv.setImageDrawable(d.constantState?.newDrawable() ?: d) }
        }
    }

    private fun showApps() {
        layer = 1
        settingsLayer.visibility = View.GONE
        fadeIn(appsLayer)
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        val t = prefs.getInt("tileDp", 96)
        grid.numColumns = ((resources.displayMetrics.widthPixels - dp(120)) / dp(t + 40)).coerceAtLeast(3)
        grid.selector = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0x26FFFFFF); setStroke(dp(3), accent) }
        grid.adapter = appsAdapter
        grid.requestFocus()
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int): Any = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val a = apps[p]
            val v = (cv ?: cell()) as LinearLayout
            (v.getChildAt(1) as TextView).text = a.label
            bindIcon(a, v.getChildAt(0) as ImageView)
            return v
        }
    }

    private fun cell(): LinearLayout {
        val t = dp(prefs.getInt("tileDp", 96))
        val iv = ImageView(this)
        styleIcon(iv, t)
        val tv = labelView("")
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(10), dp(6), dp(8))
            addView(iv, LinearLayout.LayoutParams(t, t))
            addView(tv, LinearLayout.LayoutParams(t + dp(16), -2).apply { topMargin = dp(6) })
        }
    }

    // ================= настройки: каркас страниц =================
    private fun openPage(back: (() -> Unit)?) {
        layer = if (back == null) 2 else 3
        val closer: () -> Unit = { closeLayers() }
        backTarget = back ?: closer
        appsLayer.visibility = View.GONE
        fadeIn(settingsLayer)
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        panel.removeAllViews()
    }

    // ----- главное меню -----
    private fun showSettings() {
        openPage(null)
        panelTitle("Настройки")
        section("ОФОРМЛЕНИЕ")
        val first = menuRow("Тема и обои", "›") { showThemeWall() }
        menuRow("Цвета интерфейса", "›") { showColors() }
        section("РАСКЛАДКА")
        menuRow("Избранное", "›") { showFav() }
        menuRow("Текст и значки", "›") { showText() }
        section("СИСТЕМА")
        menuRow("Настройки Android", "›") { openSystemSettings() }
        menuRow("Сбросить всё", null) { resetAll() }
        menuRow("Закрыть", null) { closeLayers() }
        first.requestFocus()
    }

    // ----- тема и обои -----
    private fun showThemeWall() {
        openPage { showSettings() }
        panelTitle("Тема и обои")
        section("ГОТОВЫЕ ТЕМЫ (ФОН + АКЦЕНТ)")
        val cards = themes.map { themeCard(it) }
        addSwatches(cards, 4, dp(104), dp(70))
        section("ОБОИ")
        slider("Затемнение обоев", 80, prefs.getInt("dim", 40), 5, { "$it%" }) { p ->
            prefs.edit().putInt("dim", p).apply(); applyDim()
        }
        menuRow("Своя картинка из файла", null) { pickImage() }
        menuRow("Картинка по ссылке", null) { askUrl() }
        menuRow("Назад", null) { showSettings() }
        cards[0].requestFocus()
    }

    // ----- цвета -----
    private fun showColors() {
        openPage { showSettings() }
        panelTitle("Цвета интерфейса")
        section("ЦВЕТ АКЦЕНТА")
        val accents = listOf("#3D8BFF", "#00BCD4", "#1DE9B6", "#4CAF50", "#C6FF00", "#FFD600",
            "#FF9100", "#FF5252", "#FF4081", "#E040FB", "#7C4DFF", "#FFFFFF").map { col(it) }
        val views = accents.map { c -> swatch(intArrayOf(c)) { setAccent(c) } }
        addSwatches(views, 6, dp(64), dp(44))
        val hsv = FloatArray(3)
        Color.colorToHSV(accent, hsv)
        slider("Свой оттенок", 360, hsv[0].toInt(), 8, { "$it°" }) { p ->
            setAccent(Color.HSVToColor(floatArrayOf(p.toFloat(), 0.75f, 1f)))
        }
        section("ФОН ЗА ИЗБРАННЫМ")
        val bgs = listOf("#000000", "#10141C", "#1B2230", "#FFFFFF", "#3D8BFF",
            "#7C4DFF", "#FF5252", "#4CAF50", "#FFD600", "#FF9100").map { col(it) }
        val bgViews = bgs.map { c -> swatch(intArrayOf(c)) { prefs.edit().putInt("favBg", c).apply(); applyFavBg() } }
        addSwatches(bgViews, 5, dp(80), dp(44))
        slider("Прозрачность фона", 100, 100 - prefs.getInt("favOp", 35), 5, { "$it%" }) { p ->
            prefs.edit().putInt("favOp", 100 - p).apply(); applyFavBg()
        }
        menuRow("Назад", null) { showSettings() }
        views[0].requestFocus()
    }

    // ----- избранное -----
    private fun showFav() {
        openPage { showSettings() }
        panelTitle("Избранное")
        section("СЕТКА")
        stepper("Строки", "favRows", 1, 1, 4, 1, "") { renderFavs() }
        stepper("Столбцы", "favCols", 7, 2, 12, 1, "") { renderFavs() }
        section("ПОРЯДОК")
        menuRow("Изменить порядок приложений", "›") { reorderFromSettings() }
        menuRow("Назад", null) { showSettings() }
        (panel.getChildAt(2) as ViewGroup).getChildAt(1).requestFocus()
    }

    // ----- текст и значки -----
    private fun showText() {
        openPage { showSettings() }
        panelTitle("Текст и значки")
        section("ТЕКСТ")
        stepper("Подписи приложений", "txtPct", 100, 70, 200, 10, "%") { renderFavs() }
        stepper("Часы и дата", "clkPct", 100, 70, 200, 10, "%") { applyClockSize() }
        section("ЗНАЧКИ")
        stepper("Размер значков", "tileDp", 96, 48, 156, 12, "") { renderFavs() }
        val names = arrayOf("Скруглённые", "Круглые", "Квадратные")
        menuRow("Форма значков", names[prefs.getInt("shape", 0)]) { }.let { row ->
            row.setOnClickListener {
                val n = (prefs.getInt("shape", 0) + 1) % 3
                prefs.edit().putInt("shape", n).apply()
                (row.tag as TextView).text = names[n]
                renderFavs()
            }
        }
        menuRow("Назад", null) { showSettings() }
        (panel.getChildAt(2) as ViewGroup).getChildAt(1).requestFocus()
    }

    private fun reorderFromSettings() {
        val first = favs().firstOrNull { byPkg.containsKey(it) }
        if (first == null) { toast("Избранное пусто"); return }
        startMove(first)
    }

    private fun openSystemSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Не удалось открыть настройки системы") }
    }

    private fun setAccent(c: Int) { accent = c; prefs.edit().putInt("accent", c).apply() }

    private fun applyThemePreset(t: Theme) {
        accent = t.accent
        prefs.edit().putInt("accent", t.accent).putString("wp_type", "grad").putString("wp_c", t.bg.joinToString(",")).apply()
        applyWallpaper()
        toast("Тема: " + t.name)
    }

    private fun resetAll() {
        prefs.edit().clear().apply()
        File(filesDir, "wallpaper.jpg").delete()
        movePkg = null
        accent = themes[0].accent
        applyWallpaper(); applyDim(); applyFavBg(); applyClockSize(); renderFavs(); showSettings()
        toast("Сброшено")
    }

    // ================= обои =================
    private fun applyWallpaper() {
        if (prefs.getString("wp_type", "grad") == "image") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) {
                io.execute {
                    val bmp = BitmapFactory.decodeFile(f.path)
                    if (bmp != null) ui.post { wall.background = null; wall.setImageBitmap(bmp) }
                }
                return
            }
        }
        val c = (prefs.getString("wp_c", null) ?: themes[0].bg.joinToString(","))
            .split(",").mapNotNull { it.trim().toIntOrNull() }
        val one = c.firstOrNull() ?: Color.BLACK
        val arr = if (c.size >= 2) c.toIntArray() else intArrayOf(one, one)
        wall.setImageDrawable(null)
        wall.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, arr)
    }

    private fun pickImage() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 7)
        } catch (e: Exception) { toast("На этом ТВ нет выбора файлов — используйте ссылку") }
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (rc == 7 && res == RESULT_OK) io.execute {
            try { contentResolver.openInputStream(u)!!.use { saveWallpaper(it.readBytes()) } }
            catch (e: Exception) { ui.post { toast("Не удалось загрузить картинку") } }
        }
    }

    private fun askUrl() {
        val et = EditText(this).apply { hint = "https://..."; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Ссылка на картинку").setView(et)
            .setPositiveButton("Загрузить") { _, _ ->
                val u = et.text.toString().trim()
                toast("Загрузка…")
                io.execute {
                    try {
                        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 8000; c.readTimeout = 15000
                        saveWallpaper(c.inputStream.use { it.readBytes() })
                    } catch (e: Exception) { ui.post { toast("Не удалось загрузить") } }
                }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun saveWallpaper(b: ByteArray) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 1920) s *= 2
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            ?: throw IllegalStateException("bad image")
        File(filesDir, "wallpaper.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        prefs.edit().putString("wp_type", "image").apply()
        ui.post { applyWallpaper(); toast("Обои установлены") }
    }

    // ================= элементы меню =================
    private fun panelTitle(t: String) {
        panel.addView(TextView(this).apply {
            text = t; textSize = 24f; setTextColor(Color.WHITE); setPadding(dp(4), 0, 0, dp(8))
        })
    }

    private fun section(t: String) {
        panel.addView(TextView(this).apply {
            text = t; textSize = 12f; letterSpacing = 0.12f; setTextColor(col("#7E8FA3"))
            setPadding(dp(6), dp(12), 0, dp(6))
        })
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 15f; setTextColor(col("#B8C7D9")); setPadding(dp(6), dp(6), 0, dp(2))
    }

    private fun rowBg(f: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(16).toFloat(); setColor(if (f) accent else 0x1AFFFFFF)
    }

    /** Строка меню: название слева, значение или › справа. Фокус = акцентная заливка с читаемым текстом */
    private fun menuRow(title: String, value: String?, onClick: () -> Unit): LinearLayout {
        val t = TextView(this).apply { text = title; textSize = 18f; setTextColor(Color.WHITE) }
        val v = TextView(this).apply { text = value ?: ""; textSize = 17f; setTextColor(col("#9FB0C3")) }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isFocusable = true; isClickable = true
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            addView(v, LinearLayout.LayoutParams(-2, -2))
        }
        row.tag = v
        row.background = rowBg(false)
        row.setOnFocusChangeListener { _, f ->
            row.background = rowBg(f)
            t.setTextColor(if (f) onAccent(accent) else Color.WHITE)
            v.setTextColor(if (f) onAccent(accent) else col("#9FB0C3"))
            row.animate().scaleX(if (f) 1.02f else 1f).scaleY(if (f) 1.02f else 1f).setDuration(110).start()
        }
        row.setOnClickListener { onClick() }
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        return row
    }

    private fun smallBtn(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(20), dp(8), dp(20), dp(8))
        isFocusable = true; isClickable = true
        background = rowBg(false)
        setOnFocusChangeListener { v, f ->
            v.background = rowBg(f)
            (v as TextView).setTextColor(if (f) onAccent(accent) else Color.WHITE)
        }
        setOnClickListener { onClick() }
    }

    /** Строка «название  [-]  значение  [+]» */
    private fun stepper(title: String, key: String, def: Int, min: Int, max: Int, step: Int, suffix: String, onChange: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0x14FFFFFF) }
        }
        val tv = TextView(this).apply { text = title; textSize = 17f; setTextColor(Color.WHITE) }
        val vt = TextView(this).apply {
            text = prefs.getInt(key, def).toString() + suffix; textSize = 18f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        fun change(d: Int) {
            val n = (prefs.getInt(key, def) + d * step).coerceIn(min, max)
            prefs.edit().putInt(key, n).apply()
            vt.text = n.toString() + suffix
            onChange()
        }
        row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(smallBtn("-") { change(-1) })
        row.addView(vt, LinearLayout.LayoutParams(dp(72), -2))
        row.addView(smallBtn("+") { change(1) })
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    /** Ползунок с подписью; стрелки влево/вправо меняют значение */
    private fun slider(title: String, max: Int, value: Int, step: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): SeekBar {
        val tl = label(title + ": " + fmt(value))
        panel.addView(tl)
        val sb = SeekBar(this).apply {
            this.max = max; keyProgressIncrement = step; progress = value
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) { tl.text = title + ": " + fmt(p); onChange(p) }
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        panel.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2); bottomMargin = dp(10) })
        return sb
    }

    private fun addSwatches(v: List<View>, per: Int, w: Int, h: Int) {
        v.chunked(per).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { r.addView(it, LinearLayout.LayoutParams(w, h).apply { rightMargin = dp(8); bottomMargin = dp(8) }) }
            panel.addView(r)
        }
    }

    private fun swatch(colors: IntArray, onClick: () -> Unit): View {
        val v = View(this)
        val cs = if (colors.size == 1) intArrayOf(colors[0], colors[0]) else colors
        fun bg(f: Boolean) = GradientDrawable(GradientDrawable.Orientation.TL_BR, cs).apply {
            cornerRadius = dp(14).toFloat(); setStroke(if (f) dp(3) else 0, Color.WHITE)
        }
        v.background = bg(false)
        v.isFocusable = true; v.isClickable = true
        v.setOnFocusChangeListener { _, f ->
            v.background = bg(f)
            v.animate().scaleX(if (f) 1.08f else 1f).scaleY(if (f) 1.08f else 1f).setDuration(110).start()
        }
        v.setOnClickListener { onClick() }
        return v
    }

    private fun themeCard(t: Theme): View {
        val fl = FrameLayout(this)
        fun bg(f: Boolean) = GradientDrawable(GradientDrawable.Orientation.TL_BR, t.bg).apply {
            cornerRadius = dp(14).toFloat(); setStroke(if (f) dp(3) else dp(1), if (f) Color.WHITE else 0x33FFFFFF)
        }
        fl.background = bg(false)
        fl.isFocusable = true; fl.isClickable = true
        fl.addView(TextView(this).apply {
            text = t.name; textSize = 13f; setTextColor(Color.WHITE)
            setShadowLayer(3f, 0f, 1f, 0xCC000000.toInt())
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(10); bottomMargin = dp(8) })
        fl.addView(View(this).apply {
            background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(t.accent) }
        }, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP or Gravity.END).apply { topMargin = dp(8); rightMargin = dp(8) })
        fl.setOnFocusChangeListener { v, f ->
            v.background = bg(f)
            v.animate().scaleX(if (f) 1.06f else 1f).scaleY(if (f) 1.06f else 1f).setDuration(110).start()
        }
        fl.setOnClickListener { applyThemePreset(t) }
        return fl
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val DEFAULT_FAVS = "com.google.android.youtube.tv|org.xbmc.kodi|com.netflix.ninja"
    }
}
