package com.fast.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.view.KeyEvent
import android.content.*
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class App(val pkg: String, val label: String, val ri: ResolveInfo)

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var content: LinearLayout
    private var dirty = true
    private var stamp = -1L
    private var tileDp = 96
    private var accent = Color.parseColor("#3D8BFF")

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { dirty = true }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false; clipToPadding = false
            setPadding(dp(48), dp(32), dp(48), dp(32))
        }
        setContentView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false; clipToPadding = false
            addView(content)
        })
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
    }

    override fun onResume() {
        super.onResume()
        val f = cfgFile()
        if (dirty || f.lastModified() != stamp) { dirty = false; stamp = f.lastModified(); reload() }
    }

    override fun onDestroy() { unregisterReceiver(pkgReceiver); super.onDestroy() }
    override fun onBackPressed() { /* лаунчер не закрывается */ }

    // ---------- конфиг ----------
    private fun cfgFile() = File(getExternalFilesDir(null) ?: filesDir, "launcher.json")

    private fun loadCfg(): JSONObject {
        val f = cfgFile()
        return try {
            if (!f.exists()) f.writeText(DEFAULT_CFG)
            JSONObject(f.readText())
        } catch (e: Exception) { JSONObject(DEFAULT_CFG) } // битый JSON не ломает лаунчер
    }

    // ---------- данные ----------
    private fun loadApps(): List<App> {
        val pm = packageManager
        val out = LinkedHashMap<String, App>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName || out.containsKey(p)) continue
                out[p] = App(p, ri.loadLabel(pm).toString(), ri)
            }
        }
        return out.values.sortedBy { it.label.lowercase() }
    }

    private fun reload() = io.execute {
        val cfg = loadCfg(); val apps = loadApps()
        ui.post { render(cfg, apps) }
        syncRemote(cfg)
    }

    // ---------- отрисовка ----------
    private fun render(cfg: JSONObject, apps: List<App>) {
        tileDp = cfg.optInt("tileDp", 96)
        accent = parseColor(cfg.optString("accent"), accent)
        window.decorView.setBackgroundColor(parseColor(cfg.optString("background"), Color.parseColor("#0E1217")))
        content.removeAllViews()
        val byPkg = apps.associateBy { it.pkg }
        val rows = cfg.optJSONArray("rows") ?: JSONArray()
        for (i in 0 until rows.length()) {
            val r = rows.optJSONObject(i) ?: continue
            r.optString("title").takeIf { it.isNotEmpty() }?.let { content.addView(title(it)) }
            if (r.optString("type") == "widget") {
                val w = Widgets.map[r.optString("widget")]?.create(this, r) ?: continue
                content.addView(w, lp(bottom = 16))
            } else {
                val list = when (val a = r.opt("apps")) {
                    is JSONArray -> (0 until a.length()).mapNotNull { byPkg[a.optString(it)] }
                    else -> apps // "*" = все
                }
                content.addView(appRow(list), lp(bottom = 24))
            }
        }
        content.addView(TextView(this).apply {
            text = "⚙  Настройки (кнопка Menu)"; textSize = 14f; setTextColor(Color.parseColor("#8FA3B8"))
            isFocusable = true; isClickable = true; setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { openEditor() }
            setOnFocusChangeListener { v, f -> v.setBackgroundColor(if (f) accent and 0x00FFFFFF or 0x66000000 else 0) }
        })
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_SETTINGS) { openEditor(); return true }
        return super.onKeyDown(k, e)
    }

    private fun openEditor() {
        val et = EditText(this).apply {
            setText(try { cfgFile().readText() } catch (e: Exception) { DEFAULT_CFG })
            textSize = 13f; setHorizontallyScrolling(false); gravity = Gravity.TOP
        }
        AlertDialog.Builder(this).setTitle("launcher.json").setView(et)
            .setPositiveButton("Сохранить") { _, _ ->
                try { JSONObject(et.text.toString()); cfgFile().writeText(et.text.toString()); dirty = true; onResume() }
                catch (e: Exception) { Toast.makeText(this, "Ошибка в JSON: ${e.message}", Toast.LENGTH_LONG).show() }
            }
            .setNeutralButton("Сбросить") { _, _ -> cfgFile().writeText(DEFAULT_CFG); dirty = true; onResume() }
            .setNegativeButton("Отмена", null).show()
    }

    // Если в json есть "configUrl", конфиг подтягивается из интернета (редактируете с телефона)
    private fun syncRemote(cfg: JSONObject) {
        val u = cfg.optString("configUrl"); if (u.isEmpty()) return
        try {
            val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 4000; c.readTimeout = 4000
            val t = c.inputStream.bufferedReader().use { it.readText() }
            val j = JSONObject(t)
            if (t != cfgFile().readText()) {
                cfgFile().writeText(t); stamp = cfgFile().lastModified()
                val apps = loadApps(); ui.post { render(j, apps) }
            }
        } catch (_: Exception) {}
    }

    private fun appRow(list: List<App>): View {
        val row = LinearLayout(this).apply { clipChildren = false; clipToPadding = false; setPadding(0, dp(8), 0, dp(8)) }
        list.forEach { row.addView(tile(it), LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(12) }) }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false; clipToPadding = false
            addView(row)
        }
    }

    private fun tile(a: App): View {
        val iv = ImageView(this)
        val tv = TextView(this).apply {
            text = a.label; textSize = 13f; setTextColor(Color.WHITE)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true; isClickable = true
            setPadding(dp(10), dp(10), dp(10), dp(8))
            addView(iv, LinearLayout.LayoutParams(dp(tileDp), dp(tileDp)))
            addView(tv, LinearLayout.LayoutParams(dp(tileDp), -2))
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.1f else 1f).scaleY(if (f) 1.1f else 1f).setDuration(90).start()
                v.background = if (f) GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(accent and 0x00FFFFFF or 0x66000000) } else null
            }
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_MAIN).setClassName(a.pkg, a.ri.activityInfo.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            setOnLongClickListener { // долгое нажатие OK = инфо о приложении (удаление/очистка)
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
            }
        }
        io.execute { val d = a.ri.loadIcon(packageManager); ui.post { iv.setImageDrawable(d) } } // иконки не тормозят UI
        return t
    }

    private fun title(s: String) = TextView(this).apply {
        text = s; textSize = 16f; setTextColor(Color.parseColor("#8FA3B8")); setPadding(dp(4), dp(8), 0, 0)
    }

    private fun lp(bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun parseColor(s: String, def: Int) = try { Color.parseColor(s) } catch (e: Exception) { def }

    companion object {
        const val DEFAULT_CFG = """{
  "background": "#0E1217",
  "accent": "#3D8BFF",
  "tileDp": 96,
  "rows": [
    { "type": "widget", "widget": "clock", "format": "HH:mm", "size": 56 },
    { "type": "widget", "widget": "date", "size": 20 },
    { "title": "Избранное", "type": "apps", "apps": ["com.google.android.youtube.tv", "org.xbmc.kodi", "com.netflix.ninja"] },
    { "title": "Все приложения", "type": "apps", "apps": "*" }
  ]
}"""
    }
}
