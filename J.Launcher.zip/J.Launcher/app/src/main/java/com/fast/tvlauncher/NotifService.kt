package com.fast.tvlauncher

import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.CopyOnWriteArrayList

/** Слушатель уведомлений: сам ничего не хранит, только сообщает MainActivity об изменениях. */
class NotifService : NotificationListenerService() {

    companion object {
        @Volatile var instance: NotifService? = null
        val listeners = CopyOnWriteArrayList<() -> Unit>()
        private val main = Handler(Looper.getMainLooper())

        fun fire() {
            main.post { for (l in listeners) try { l() } catch (e: Throwable) { } }
        }
    }

    override fun onListenerConnected() { instance = this; fire() }

    override fun onListenerDisconnected() {
        if (instance === this) instance = null
        fire()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) { fire() }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) { fire() }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
