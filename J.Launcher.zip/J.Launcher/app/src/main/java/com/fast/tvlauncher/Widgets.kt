package com.fast.tvlauncher

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.TextClock
import android.widget.TextView
import org.json.JSONObject

fun interface WidgetFactory { fun create(c: Context, cfg: JSONObject): View }

/**
 * РЕЕСТР ВИДЖЕТОВ. Чтобы добавить свой — допиши строку в map:
 *   "имя" to WidgetFactory { c, cfg -> ...вернуть любой View... }
 * и используй его в launcher.json: {"type":"widget","widget":"имя", ...свои поля...}
 */
object Widgets {
    val map = mutableMapOf<String, WidgetFactory>(
        // Часы (обновляются сами, без таймеров с нашей стороны)
        "clock" to WidgetFactory { c, cfg ->
            TextClock(c).apply {
                val f = cfg.optString("format", "HH:mm")
                format24Hour = f; format12Hour = f
                textSize = cfg.optDouble("size", 56.0).toFloat()
                setTextColor(Color.parseColor(cfg.optString("color", "#FFFFFF")))
            }
        },
        // Дата
        "date" to WidgetFactory { c, cfg ->
            TextClock(c).apply {
                val f = cfg.optString("format", "EEEE, d MMMM")
                format24Hour = f; format12Hour = f
                textSize = cfg.optDouble("size", 20.0).toFloat()
                setTextColor(Color.parseColor(cfg.optString("color", "#AABBCC")))
            }
        },
        // Произвольный текст
        "text" to WidgetFactory { c, cfg ->
            TextView(c).apply {
                text = cfg.optString("text", "")
                textSize = cfg.optDouble("size", 20.0).toFloat()
                setTextColor(Color.parseColor(cfg.optString("color", "#FFFFFF")))
            }
        }
    )
}
