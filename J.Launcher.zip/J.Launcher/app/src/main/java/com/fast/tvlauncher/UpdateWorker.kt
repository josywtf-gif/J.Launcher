package com.fast.tvlauncher

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

object UpdateChecker {
    class Info(val remote: Int, val url: String)

    val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private const val API = "https://api.github.com/repos/josywtf-gif/J.Launcher/releases/latest"
    private const val HTML = "https://github.com/josywtf-gif/J.Launcher/releases"

    fun fire() { main.post { for (l in listeners) try { l() } catch (e: Throwable) { } } }

    fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** Номер текущей сборки из versionName «1.N» */
    fun cur(c: Context): Int = (try { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "" } catch (e: Exception) { "" })
        .substringAfter('.').toIntOrNull() ?: 0

    /** Запрос к GitHub (бросает исключение при ошибке сети) */
    fun fetch(): Info {
        val c = java.net.URL(API).openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        val j = JSONObject(c.inputStream.use { String(it.readBytes()) })
        val remote = j.optString("tag_name", "").trimStart('v', 'V').toIntOrNull() ?: 0
        var url = j.optString("html_url", HTML)
        val assets = j.optJSONArray("assets")
        if (assets != null) for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url", url); break }
        }
        return Info(remote, url)
    }

    fun store(c: Context, i: Info) {
        prefs(c).edit().putInt("updRemote", i.remote).putString("updUrl", i.url).apply()
    }

    /** (Пере)регистрация периодической задачи по настройкам. force = true при изменении настроек */
    fun schedule(c: Context, force: Boolean) {
        val wm = WorkManager.getInstance(c)
        val p = prefs(c)
        if (p.getInt("updAuto", 0) != 1) { wm.cancelUniqueWork("jl_upd"); return }
        val hours = longArrayOf(1, 6, 24, 72, 168)[p.getInt("updFreq", 2).coerceIn(0, 4)]
        val req = PeriodicWorkRequestBuilder<UpdateWorker>(hours, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork(
            "jl_upd",
            if (force) ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE else ExistingPeriodicWorkPolicy.UPDATE,
            req
        )
    }
}

class UpdateWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        if (UpdateChecker.prefs(applicationContext).getInt("updAuto", 0) != 1) return Result.success()
        try {
            UpdateChecker.store(applicationContext, UpdateChecker.fetch())
            UpdateChecker.fire()
        } catch (e: Throwable) { }
        return Result.success()
    }
}
