package com.fast.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import androidx.core.content.FileProvider
import android.content.*
import android.content.pm.ResolveInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

private fun col(s: String) = Color.parseColor(s)
private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

/** Смешивание двух цветов: t = 0 -> a, t = 1 -> b (результат непрозрачный) */
private fun mix(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    return Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
    )
}

/** Относительная яркость по WCAG */
private fun lum(c: Int): Double {
    fun f(v: Int): Double {
        val s = v / 255.0
        return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }
    return 0.2126 * f(Color.red(c)) + 0.7152 * f(Color.green(c)) + 0.0722 * f(Color.blue(c))
}

private fun contrast(a: Int, b: Int): Double {
    val x = lum(a)
    val y = lum(b)
    return (maxOf(x, y) + 0.05) / (minOf(x, y) + 0.05)
}

private val DARK_TXT = 0xFF111111.toInt()

/** Цвет текста поверх фона c: белый или тёмный — тот, у которого контраст выше */
private fun onAccent(c: Int): Int = if (contrast(Color.WHITE, c) >= contrast(DARK_TXT, c)) Color.WHITE else DARK_TXT

class MainActivity : Activity() {

    private class App(val pkg: String, val label: String, val ri: ResolveInfo, val cat: String)
    private class Theme(val name: String, val bg: IntArray, val accent: Int)
    private class Slot(val pkg: String, var r: Int, var c: Int)
    private class IconData(val banner: Drawable?, val icon: Drawable, val bg: Int)

    /** Кнопка-иконка: kind 0 = шестерёнка, 1 = сетка «все приложения» */
    private class IconBtn(c: Context, private val kind: Int, private val accentOf: () -> Int) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        init {
            isFocusable = true; isClickable = true
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.12f else 1f).scaleY(if (f) 1.12f else 1f).setDuration(110).start()
                v.invalidate()
            }
        }
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val acc = accentOf()
            p.style = Paint.Style.FILL
            p.color = if (isFocused) acc else 0x40FFFFFF
            cv.drawRoundRect(0f, 0f, w, h, w * 0.32f, w * 0.32f, p)
            p.color = if (isFocused) onAccent(acc) else Color.WHITE
            val cx = w / 2
            val cy = h / 2
            if (kind == 0) {
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = w * 0.10f
                cv.drawCircle(cx, cy, w * 0.20f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cs = Math.cos(a).toFloat()
                    val sn = Math.sin(a).toFloat()
                    cv.drawLine(cx + cs * w * 0.30f, cy + sn * w * 0.30f, cx + cs * w * 0.38f, cy + sn * w * 0.38f, p)
                }
            } else {
                val s = w * 0.15f
                val g = w * 0.07f
                val x0 = cx - (1.5f * s + g)
                val y0 = cy - (1.5f * s + g)
                for (ri in 0..2) {
                    for (ci in 0..2) {
                        val x = x0 + ci * (s + g)
                        val y = y0 + ri * (s + g)
                        cv.drawRoundRect(x, y, x + s, y + s, s / 3, s / 3, p)
                    }
                }
            }
        }
    }

    /** Кнопка VPN: белый ключ = включён, светло-серый перечёркнутый ключ = выключен */
    private class VpnBtn(c: Context, private val accentOf: () -> Int, private val isOn: () -> Boolean) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        init {
            isFocusable = true; isClickable = true
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.12f else 1f).scaleY(if (f) 1.12f else 1f).setDuration(110).start()
                v.invalidate()
            }
        }
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val on = isOn()
            val acc = accentOf()
            p.style = Paint.Style.FILL
            p.color = if (isFocused) acc else 0x40FFFFFF
            cv.drawRoundRect(0f, 0f, w, h, w * 0.32f, w * 0.32f, p)
            p.color = if (isFocused) onAccent(acc) else if (on) Color.WHITE else 0xFFC3CAD3.toInt()
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = w * 0.075f
            val cx = w / 2
            val cy = h / 2
            cv.save()
            cv.rotate(-45f, cx, cy)
            cv.drawCircle(cx - w * 0.20f, cy, w * 0.11f, p)
            cv.drawLine(cx - w * 0.09f, cy, cx + w * 0.26f, cy, p)
            cv.drawLine(cx + w * 0.16f, cy, cx + w * 0.16f, cy + w * 0.11f, p)
            cv.drawLine(cx + w * 0.26f, cy, cx + w * 0.26f, cy + w * 0.11f, p)
            cv.restore()
            if (!on) cv.drawLine(w * 0.22f, h * 0.22f, w * 0.78f, h * 0.78f, p)
        }
    }

    private val themes = listOf(
        Theme("Полночь", intArrayOf(col("#070B16"), col("#0F1B33"), col("#1B3358")), col("#5AA9FF")),
        Theme("Океан", intArrayOf(col("#031A27"), col("#0A3B4A"), col("#12636E")), col("#3DD9E8")),
        Theme("Закат", intArrayOf(col("#1A0A24"), col("#4A1740"), col("#8A3A3A")), col("#FF9E57")),
        Theme("Лес", intArrayOf(col("#07140D"), col("#12301D"), col("#245A33")), col("#A5E36B")),
        Theme("Графит", intArrayOf(col("#0C0D0F"), col("#17191D"), col("#25282E")), col("#B8C4CE")),
        Theme("Неон", intArrayOf(col("#07000F"), col("#1D0A38"), col("#002B45")), col("#00E5FF")),
        Theme("Сакура", intArrayOf(col("#1C0B16"), col("#44213A"), col("#7A3B5C")), col("#FF8FB8")),
        Theme("Пустыня", intArrayOf(col("#1B1109"), col("#43301B"), col("#7A5A30")), col("#FFC857")),
        Theme("Индиго", intArrayOf(col("#0A0A24"), col("#1A1A4D"), col("#2B2B7A")), col("#9FA8FF")),
        Theme("Рубин", intArrayOf(col("#1A0508"), col("#4A0F1A"), col("#7C1D2E")), col("#FF6B7D")),
        Theme("Изумруд", intArrayOf(col("#03160F"), col("#06402F"), col("#0B6B4F")), col("#34E0A1")),
        Theme("Чёрный", intArrayOf(col("#000000"), col("#050505"), col("#0D0D0D")), col("#FFFFFF"))
    )

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val iconCache = ConcurrentHashMap<String, IconData>()
    // плитки двух блоков главного экрана: [0] = Первое окно, [1] = Второе окно
    private val favTiles = arrayOf(HashMap<String, View>(), HashMap<String, View>())
    private val homeEmpty = booleanArrayOf(true, true)
    private val themed = ArrayList<() -> Unit>()   // перекраска элементов текущей страницы настроек при смене акцента
    private val vpnNets = HashSet<Network>()
    private var apps: List<App> = emptyList()
    private var byPkg: Map<String, App> = emptyMap()
    private var appsLoaded = false
    private var dirty = true
    private var accent = 0
    private var layer = 0 // 0 главный, 1 все приложения, 2 настройки, 3 подраздел
    private var backTarget: () -> Unit = {}
    private var movePkg: String? = null
    private var moveBlk = 0                  // блок, в котором идёт перемещение
    private var lastPkg: String? = null      // последняя выбранная плитка на главном экране
    private var lastBlk = 0                  // блок последней выбранной плитки
    private var lastAppsPkg: String? = null  // последний выбранный пункт в меню всех приложений
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var wpToken = 0

    private val renderRun = Runnable { renderFavs() }
    private val vpnRefresh = Runnable { updateVpn() }

    // размеры плиток меню «Все приложения» (считаются при открытии)
    private var aW = 0
    private var aH = 0
    private var aRad = 0f
    private var aSq = false

    private lateinit var wall: ImageView
    private lateinit var scrim: View
    private lateinit var mainCol: LinearLayout
    private lateinit var splitRoot: LinearLayout          // контейнер двух блоков (веса 1:1 или по настройке)
    private lateinit var scrolls: Array<ScrollView>       // блок = ScrollView
    private lateinit var homeBoxes: Array<LinearLayout>
    private lateinit var favGrids: Array<LinearLayout>
    private lateinit var appsIcon: IconBtn
    private lateinit var gearV: IconBtn
    private lateinit var vpnBtn: VpnBtn
    private lateinit var appsCard: LinearLayout
    private lateinit var appsTitle: TextView
    private var vpnOn = false
    private lateinit var appsLayer: FrameLayout
    private lateinit var grid: GridView
    private lateinit var appsAdapter: AppsAdapter
    private lateinit var settingsLayer: FrameLayout
    private lateinit var panel: LinearLayout
    private var clockV: TextView? = null
    private var dateV: TextView? = null

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { dirty = true }
    }

    // ================= ключи настроек по блокам =================
    /**
     * Первое окно использует прежние ключи (старые настройки сохраняются), Второе окно — ключи с суффиксом «2».
     * Цвет/фон/прозрачность окон полностью независимы: favBg/favOp (окно 1) и favBg2/favOp2 (окно 2).
     */
    private fun pk(key: String, b: Int) = if (b == 0) key else key + "2"
    private fun pi(key: String, def: Int, b: Int) = prefs.getInt(pk(key, b), def)
    private fun favBgDef(b: Int) = if (b == 0) Color.BLACK else col("#1B3358")
    private fun favOpDef(b: Int) = if (b == 0) 35 else 55
    private fun split() = prefs.getInt("split", 0) == 1
    private fun splitShare() = prefs.getInt("splitW", 50).coerceIn(25, 75)
    private fun winName(b: Int) = if (b == 0) "первое окно" else "второе окно"

    /** true = блоки рядом (слева/справа), false = один под другим. Авто: по ориентации экрана */
    private fun splitHoriz(): Boolean {
        val dm = resources.displayMetrics
        return when (prefs.getInt("splitDir", 0)) {
            1 -> true
            2 -> false
            else -> dm.widthPixels >= dm.heightPixels
        }
    }

    // ================= жизненный цикл =================
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        accent = prefs.getInt("accent", themes[0].accent)
        lastPkg = prefs.getString("lastPkg", null)
        lastBlk = prefs.getInt("lastBlk", 0)
        buildUi()
        applyWallpaper(); applyDim(); applySplit(); applyFavBg(); applyClock(); applyBtnSize(); applyAppsBg()
        applyPanelBg(); applyFont()
        cleanUpdates()
        registerNet()
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        // поворот / смена размера экрана: пересчитать направление блоков и размеры плиток
        applySplit(); renderFavs()
    }

    override fun onResume() {
        super.onResume()
        if (dirty) { dirty = false; loadApps() }
        updateVpn()
        if (installPending) { installPending = false; ui.postDelayed({ cleanUpdates() }, 1000) }
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putString("lastPkg", lastPkg).putInt("lastBlk", lastBlk).apply()
        if (movePkg != null) { movePkg = null; renderFavs() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (movePkg != null) { movePkg = null; renderFavs() }
        closeLayers() // Home: возвращаемся на главный экран и на последнюю выбранную плитку
    }

    override fun onDestroy() {
        dlCancel = true
        ui.removeCallbacksAndMessages(null)
        try {
            netCb?.let { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        } catch (e: Exception) { }
        netCb = null
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        io.shutdownNow()
        super.onDestroy()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (movePkg != null) {
            var dr = 0
            var dc = 0
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> dc = -1
                KeyEvent.KEYCODE_DPAD_RIGHT -> dc = 1
                KeyEvent.KEYCODE_DPAD_UP -> dr = -1
                KeyEvent.KEYCODE_DPAD_DOWN -> dr = 1
            }
            val dir = dr != 0 || dc != 0
            val end = e.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || e.keyCode == KeyEvent.KEYCODE_ENTER ||
                e.keyCode == KeyEvent.KEYCODE_BACK
            if (dir || end) {
                if (e.action == KeyEvent.ACTION_DOWN) {
                    if (dir) moveStep(dr, dc) else if (e.repeatCount == 0) endMove()
                }
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_SETTINGS) { showSettings(); return true }
        return super.onKeyDown(k, e)
    }

    override fun onBackPressed() {
        when (layer) {
            1, 2 -> closeLayers()
            3 -> backTarget()
            else -> {}
        }
    }

    // ================= каркас интерфейса =================
    private fun buildUi() {
        val root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, FrameLayout.LayoutParams(-1, -1))
        scrim = View(this)
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(40), dp(56), dp(32))
            clipChildren = false; clipToPadding = false
        }

        // строка состояния: часы + VPN слева, кнопки справа
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val widgets = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clockV = Widgets.map["clock"]?.create(this, JSONObject().put("size", 72)) as? TextView
        dateV = Widgets.map["date"]?.create(this, JSONObject().put("size", 22)) as? TextView
        vpnBtn = VpnBtn(this, { accent }, { vpnOn })
        vpnBtn.setOnClickListener { onVpnClick() }
        val clockRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        clockV?.let { shadow(it); clockRow.addView(it) }
        clockRow.addView(vpnBtn, LinearLayout.LayoutParams(dp(56), dp(56)).apply { leftMargin = dp(18) })
        widgets.addView(clockRow)
        dateV?.let { shadow(it); widgets.addView(it) }
        top.addView(widgets, LinearLayout.LayoutParams(0, -2, 1f))
        appsIcon = IconBtn(this, 1) { accent }
        appsIcon.setOnClickListener { showApps() }
        top.addView(appsIcon, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14); topMargin = dp(8) })
        gearV = IconBtn(this, 0) { accent }
        gearV.setOnClickListener { showSettings() }
        top.addView(gearV, LinearLayout.LayoutParams(dp(56), dp(56)).apply { topMargin = dp(8) })
        mainCol.addView(top, LinearLayout.LayoutParams(-1, -2))

        // главный экран: два независимых блока (Первое и Второе окно) в контейнере с весами.
        // Блок 2 скрыт (GONE), пока режим разделения выключен — тогда блок 1 занимает весь экран.
        favGrids = Array(2) {
            LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                clipChildren = false; clipToPadding = false
                setPadding(dp(14), dp(10), dp(14), dp(10))
            }
        }
        homeBoxes = Array(2) { i ->
            LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                clipChildren = false; clipToPadding = false
                setPadding(0, 0, 0, dp(36))
                addView(favGrids[i], LinearLayout.LayoutParams(-2, -2))
            }
        }
        scrolls = Array(2) { i ->
            ScrollView(this@MainActivity).apply {
                isFillViewport = true; isVerticalScrollBarEnabled = false
                clipChildren = false; clipToPadding = false
                addView(homeBoxes[i], ViewGroup.LayoutParams(-1, -1))
            }
        }
        splitRoot = LinearLayout(this).apply {
            clipChildren = false; clipToPadding = false
            addView(scrolls[0]); addView(scrolls[1])
        }
        mainCol.addView(splitRoot, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(mainCol, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Все приложения» (всплывающее окно) ---
        appsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0x66000000) }
        appsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(12))
        }
        appsTitle = TextView(this).apply {
            text = "Все приложения"; textSize = 24f; setTextColor(Color.WHITE); setPadding(dp(8), 0, 0, dp(10))
        }
        appsCard.addView(appsTitle)
        appsAdapter = AppsAdapter()
        grid = GridView(this).apply {
            adapter = appsAdapter
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(6); horizontalSpacing = dp(6)
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isVerticalScrollBarEnabled = false
            setOnItemClickListener { _, _, pos, _ -> apps.getOrNull(pos)?.let { launch(it, false) } }
            setOnItemLongClickListener { _, _, pos, _ -> apps.getOrNull(pos)?.let { appMenu(it) }; true }
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    lastAppsPkg = apps.getOrNull(position)?.pkg
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        appsCard.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        appsLayer.addView(appsCard, FrameLayout.LayoutParams(-2, -2))
        root.addView(appsLayer, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Настройки» (справа, слева виден предпросмотр) ---
        settingsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0x55000000) }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(24))
        }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(panel) }
        settingsLayer.addView(sv, FrameLayout.LayoutParams(dp(520), -2, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(40); topMargin = dp(24); bottomMargin = dp(24)
        })
        root.addView(settingsLayer, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        appsIcon.requestFocus()
    }

    private fun shadow(t: TextView) = t.setShadowLayer(5f, 0f, 2f, 0xCC000000.toInt())

    private fun fadeIn(v: View) {
        if (v.visibility != View.VISIBLE) {
            v.alpha = 0f; v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(170).start()
        }
    }

    private fun closeLayers() {
        layer = 0
        appsLayer.visibility = View.GONE
        settingsLayer.visibility = View.GONE
        mainCol.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        defaultFocus()
    }

    /** Фокус: последняя выбранная плитка, иначе первая по порядку (Первое окно, затем Второе), иначе кнопка меню */
    private fun defaultFocus() {
        val last = lastPkg?.let { favTiles[lastBlk][it] }
        if (last != null) { last.requestFocus(); return }
        for (b in 0..1) {
            val first = layoutSlots(b).sortedWith(compareBy<Slot>({ it.r }, { it.c })).firstOrNull()
            val v = first?.let { favTiles[b][it.pkg] }
            if (v != null) { v.requestFocus(); return }
        }
        appsIcon.requestFocus()
    }

    // ================= цвета и контраст =================
    private val darkRef = Color.rgb(16, 16, 20)

    /** Цвет рамки выделения: акцент, а если он сливается с фоном — цвет, читаемый на этом фоне */
    private fun ringColor(bg: Int): Int = if (contrast(accent, bg) >= 2.2) accent else onAccent(bg)

    private fun favEff(b: Int): Int =
        if (homeEmpty[b] && !split()) darkRef
        else mix(darkRef, pi("favBg", favBgDef(b), b), pi("favOp", favOpDef(b), b) / 100f)

    private fun favTxt(b: Int): Int = onAccent(favEff(b))

    private fun appsEff(): Int = mix(darkRef, prefs.getInt("aBg", col("#0B0F16")), prefs.getInt("aOp", 93) / 100f)

    private fun appsTxt(): Int = onAccent(appsEff())

    private fun styleLabel(t: TextView, c: Int) {
        t.setTextColor(c)
        t.setShadowLayer(if (lum(c) > 0.5) 4f else 0f, 0f, 2f, 0xCC000000.toInt())
    }

    private fun wpColors(): List<Int> {
        val l = (prefs.getString("wp_c", null) ?: themes[0].bg.joinToString(","))
            .split(",").mapNotNull { it.trim().toIntOrNull() }
        return if (l.isEmpty()) themes[0].bg.toList() else l
    }

    /** Цвет панели настроек берётся из текущей темы (среднего цвета фона) и затемняется до читаемого */
    private fun panelColor(): Int {
        val base = if (prefs.getString("wp_type", "grad") == "image") {
            val hsv = FloatArray(3)
            Color.colorToHSV(accent, hsv)
            Color.HSVToColor(floatArrayOf(hsv[0], 0.5f, 0.28f))
        } else {
            val w = wpColors()
            if (w.size > 1) w[1] else w[0]
        }
        var c = mix(base, Color.BLACK, 0.3f)
        var n = 0
        while (lum(c) > 0.06 && n < 6) { c = mix(c, Color.BLACK, 0.3f); n++ }
        return c
    }

    /** Панель настроек: прозрачность задаётся в «Оформление → Темы → Прозрачность системы» (ключ panelOp, по умолчанию 96%) */
    private fun applyPanelBg() {
        panel.background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(alpha(panelColor(), prefs.getInt("panelOp", 96).coerceIn(30, 100) * 255 / 100))
            setStroke(dp(2), alpha(accent, 0x55))
        }
    }

    /** Единая точка перекраски интерфейса при смене акцента или темы */
    private fun applyAccent() {
        applyPanelBg()
        for (t in themed) t()
        appsIcon.invalidate(); gearV.invalidate(); vpnBtn.invalidate()
        applyFavBg() // рамки блоков и плитки
    }

    private fun face(): Typeface = when (prefs.getInt("font", 0)) {
        1 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        2 -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        3 -> Typeface.SERIF
        else -> Typeface.DEFAULT
    }

    private fun applyFont() {
        val f = face()
        clockV?.typeface = f
        dateV?.typeface = f
        for (b in 0..1) for (v in favTiles[b].values) ((v as? ViewGroup)?.getChildAt(1) as? TextView)?.typeface = f
        if (::appsAdapter.isInitialized) appsAdapter.notifyDataSetChanged()
    }

    // ================= применение настроек =================
    private fun applyDim() {
        val d = prefs.getInt("dim", 40) * 255 / 100
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(alpha(Color.BLACK, (d + 30).coerceAtMost(255)), alpha(Color.BLACK, d), alpha(Color.BLACK, (d + 50).coerceAtMost(255)))
        )
    }

    /**
     * Разделение экрана. Оба блока лежат в одном LinearLayout с весами (0dp + weight), поэтому они
     * делят доступное место пропорционально и физически не могут наехать друг на друга.
     * Отступ между блоками задаётся margin'ом у второго блока.
     */
    private fun applySplit() {
        val sp = split()
        val horiz = splitHoriz()
        splitRoot.orientation = if (horiz) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        // в режиме разделения блоки НЕ растягиваются: каждый занимает свой размер, пара центрируется, остальное — фон
        splitRoot.gravity = if (!sp) Gravity.NO_GRAVITY else if (horiz) Gravity.CENTER_HORIZONTAL else Gravity.CENTER
        for (b in 0..1) {
            val lp = when {
                !sp -> if (horiz) LinearLayout.LayoutParams(0, -1, 1f) else LinearLayout.LayoutParams(-1, 0, 1f)
                horiz -> LinearLayout.LayoutParams(-2, -1)
                else -> LinearLayout.LayoutParams(-2, -2)
            }
            if (b == 1 && sp) { if (horiz) lp.leftMargin = dp(16) else lp.topMargin = dp(16) }
            scrolls[b].layoutParams = lp
            scrolls[b].visibility = if (b == 1 && !sp) View.GONE else View.VISIBLE
            if (sp) homeBoxes[b].setPadding(dp(8), dp(8), dp(8), dp(8))
            else homeBoxes[b].setPadding(0, 0, 0, dp(36))
        }
        applyAlign()
        splitRoot.requestLayout()
    }

    /**
     * Фон блока. В режиме разделения подложка (цвет + прозрачность + рамка) рисуется на всём блоке,
     * чтобы граница между блоками была чётко видна. Без разделения — как раньше, на панели плиток.
     */
    private fun applyFavBg(only: Int = -1) {
        val sp = split()
        for (b in 0..1) {
            if (only >= 0 && only != b) continue
            val bg = pi("favBg", favBgDef(b), b)
            val a = pi("favOp", favOpDef(b), b) * 255 / 100
            scrolls[b].background = null
            favGrids[b].background = if (homeEmpty[b] && !sp) null else GradientDrawable().apply {
                cornerRadius = dp(26).toFloat()
                setColor(alpha(bg, a))
                if (sp) setStroke(dp(2), alpha(accent, 0x66))
            }
            // подписи плиток всегда читаются на выбранном фоне панели
            val tc = favTxt(b)
            (favGrids[b].getChildAt(0) as? TextView)?.takeIf { it.tag == "hint" }?.setTextColor(tc)
            for ((k, v) in favTiles[b]) {
                ((v as? ViewGroup)?.getChildAt(1) as? TextView)?.let { styleLabel(it, tc) }
                v.background = tileBg(b, k, v.isFocused)
            }
        }
    }

    private fun applyAppsBg() {
        appsCard.background = GradientDrawable().apply {
            cornerRadius = dp(28).toFloat()
            setColor(alpha(prefs.getInt("aBg", col("#0B0F16")), prefs.getInt("aOp", 93) * 255 / 100))
        }
        appsTitle.setTextColor(appsTxt())
        appsAdapter.notifyDataSetChanged()
    }

    private fun applyAlign() {
        val v = if (split()) Gravity.CENTER_VERTICAL else Gravity.BOTTOM
        for (b in 0..1) {
            val h = when (pi("hAlign", 1, b)) {
                0 -> Gravity.START
                2 -> Gravity.END
                else -> Gravity.CENTER_HORIZONTAL
            }
            homeBoxes[b].gravity = v or h
        }
    }

    private fun applyClock() {
        val k = prefs.getInt("clkPct", 100) / 100f
        val sec = prefs.getInt("clkSec", 0) == 1
        val h24 = prefs.getInt("clk24", 1) == 1
        val f = if (h24) (if (sec) "HH:mm:ss" else "HH:mm") else (if (sec) "h:mm:ss a" else "h:mm a")
        (clockV as? TextClock)?.let { it.format24Hour = f; it.format12Hour = f }
        clockV?.textSize = 72f * k
        dateV?.textSize = 22f * k
        clockV?.visibility = if (prefs.getInt("clkShow", 1) == 1) View.VISIBLE else View.GONE
        dateV?.visibility = if (prefs.getInt("dateShow", 1) == 1) View.VISIBLE else View.GONE
    }

    private fun applyBtnSize() {
        val s = dp(prefs.getInt("btnDp", 56))
        for (v in listOf<View>(vpnBtn, appsIcon, gearV)) {
            val lp = v.layoutParams as LinearLayout.LayoutParams
            lp.width = s; lp.height = s
            v.layoutParams = lp
        }
    }

    // ================= VPN =================
    /** Колбэк следит только за VPN-сетями и хранит их набор: проходов по allNetworks при каждом событии нет */
    private fun registerNet() {
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: Network) { ui.post { vpnNets.add(n); applyVpn(true) } }
                override fun onLost(n: Network) { ui.post { vpnNets.remove(n); applyVpn(vpnNets.isNotEmpty()) } }
            }
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()
            cm.registerNetworkCallback(req, cb)
            netCb = cb
        } catch (e: Exception) { }
    }

    private fun vpnActive(): Boolean = try {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.allNetworks.any { n -> cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
    } catch (e: Exception) { false }

    /** Перерисовка и смена видимости только при реальном изменении состояния */
    private fun applyVpn(on: Boolean) {
        val mode = prefs.getInt("vpnShow", 1) // 0 скрыть, 1 всегда, 2 только когда включён
        if (vpnOn != on) { vpnOn = on; vpnBtn.invalidate() }
        val vis = if (mode == 0 || (mode == 2 && !on)) View.GONE else View.VISIBLE
        if (vpnBtn.visibility != vis) vpnBtn.visibility = vis
    }

    private fun updateVpn() = applyVpn(vpnActive())

    /** Нажатие на кнопку VPN: открыть настройки VPN, запустить выбранное приложение или отправить своё действие */
    private fun onVpnClick() {
        val on = vpnActive()
        try {
            when (prefs.getInt("vpnAct", 0)) {
                0 -> openVpnSettings()
                1 -> {
                    val a = byPkg[prefs.getString("vpnPkg", "") ?: ""]
                    if (a == null) toast("Выберите приложение VPN в настройках ВПН") else startApp(a)
                }
                else -> sendVpnIntent(on)
            }
        } catch (e: Exception) { toast("Не удалось выполнить действие") }
        ui.removeCallbacks(vpnRefresh)
        ui.postDelayed(vpnRefresh, 1500)
        ui.postDelayed(vpnRefresh, 4000)
    }

    private fun openVpnSettings() {
        try {
            startActivity(Intent("android.settings.VPN_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("На этом ТВ нет экрана настроек VPN")
            openSystemSettings()
        }
    }

    private fun sendVpnIntent(on: Boolean) {
        val onAct = (prefs.getString("vpnOnAct", "") ?: "").trim()
        val offAct = (prefs.getString("vpnOffAct", "") ?: "").trim()
        val action = if (on && offAct.isNotEmpty()) offAct else onAct
        if (action.isEmpty()) { toast("Задайте действие в настройках кнопки VPN"); return }
        val i = Intent(action)
        val pkg = (prefs.getString("vpnIPkg", "") ?: "").trim()
        if (pkg.isNotEmpty()) i.setPackage(pkg)
        (prefs.getString("vpnIExtra", "") ?: "").split(";").forEach { kv ->
            val p = kv.split("=", limit = 2)
            if (p.size == 2 && p[0].isNotBlank()) i.putExtra(p[0].trim(), p[1].trim())
        }
        when (prefs.getInt("vpnType", 0)) {
            0 -> sendBroadcast(i)
            1 -> startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else -> {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        }
    }

    // ================= приложения =================
    private fun loadApps() = io.execute {
        val pm = packageManager
        val out = LinkedHashMap<String, App>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName || out.containsKey(p)) continue
                out[p] = App(p, ri.loadLabel(pm).toString(), ri, cat)
            }
        }
        val list = out.values.sortedBy { it.label.lowercase() }
        ui.post {
            apps = list; byPkg = list.associateBy { it.pkg }; appsLoaded = true
            renderFavs(); appsAdapter.notifyDataSetChanged()
            if (layer == 0) defaultFocus()
        }
        list.forEach { if (!iconCache.containsKey(it.pkg)) iconCache[it.pkg] = loadIconData(it) }
    }

    /**
     * Запуск как из обычного лаунчера (ACTION_MAIN + категория + NEW_TASK + RESET_TASK_IF_NEEDED):
     * если приложение уже есть в недавних, Android вернёт его задачу на экран, а не запустит заново.
     */
    private fun startApp(a: App) {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(a.cat)
                .setComponent(ComponentName(a.pkg, a.ri.activityInfo.name))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        )
    }

    private fun launch(a: App, fromHome: Boolean, b: Int = 0) {
        if (fromHome) { lastPkg = a.pkg; lastBlk = b } else lastAppsPkg = a.pkg
        prefs.edit().putString("lastPkg", lastPkg).putInt("lastBlk", lastBlk).apply()
        try { startApp(a) } catch (e: Exception) { toast("Не удалось запустить") }
    }

    private fun appMenu(a: App) {
        val sp = split()
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        for (b in 0 until (if (sp) 2 else 1)) {
            val on = rawSlots(b).any { it.pkg == a.pkg }
            val nm = if (b == 0) "Первое окно" else "Второе окно"
            if (on) {
                items.add(if (sp) "Переместить: $nm" else "Переместить на главном экране"); acts.add { startMove(b, a.pkg) }
                items.add(if (sp) "Убрать: $nm" else "Убрать с главного экрана"); acts.add { removeFromHome(b, a.pkg) }
            } else {
                items.add(if (sp) "Добавить: $nm" else "Добавить на главный экран"); acts.add { addToHome(b, a.pkg) }
            }
        }
        items.add("О приложении")
        acts.add { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        items.add("Удалить")
        acts.add { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        AlertDialog.Builder(this).setTitle(a.label).setItems(items.toTypedArray()) { _, w ->
            try { acts[w]() } catch (e: Exception) { toast("Не удалось выполнить действие") }
        }.show()
    }

    // ================= плитки (как в Google TV) =================
    private fun loadIconData(a: App): IconData {
        val pm = packageManager
        val banner: Drawable? = try {
            a.ri.activityInfo.loadBanner(pm) ?: a.ri.activityInfo.applicationInfo.loadBanner(pm)
        } catch (e: Exception) { null }
        val icon = a.ri.loadIcon(pm)
        return IconData(banner, icon, avgColor(icon))
    }

    /** Средний цвет значка (для плитки у приложений без баннера), слегка затемнённый */
    private fun avgColor(d: Drawable): Int {
        return try {
            val n = 16
            val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            d.setBounds(0, 0, n, n); d.draw(cv)
            var r = 0L; var g = 0L; var b = 0L; var cnt = 0L
            for (y in 0 until n) for (x in 0 until n) {
                val px = bmp.getPixel(x, y)
                if (Color.alpha(px) > 128) { r += Color.red(px); g += Color.green(px); b += Color.blue(px); cnt++ }
            }
            bmp.recycle()
            if (cnt == 0L) col("#2A2F3A")
            else Color.rgb((r / cnt * 0.55).toInt(), (g / cnt * 0.55).toInt(), (b / cnt * 0.55).toInt())
        } catch (e: Exception) { col("#2A2F3A") }
    }

    private fun tileImage(r: Float): ImageView = ImageView(this).apply {
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
        }
        background = GradientDrawable().apply { cornerRadius = r; setColor(0x1AFFFFFF) }
    }

    private fun showIcon(iv: ImageView, d: IconData, h: Int, r: Float, square: Boolean) {
        val useBanner = !square && d.banner != null
        val dr: Drawable = if (useBanner) d.banner!! else d.icon
        iv.setImageDrawable(dr.constantState?.newDrawable() ?: dr)
        if (useBanner) {
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setPadding(0, 0, 0, 0); iv.background = null
        } else if (square) {
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(0, 0, 0, 0); iv.background = null
        } else {
            // у приложения нет баннера: значок по центру на плитке его среднего цвета
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            val p = (h * 0.16f).toInt()
            iv.setPadding(p, p, p, p)
            iv.background = GradientDrawable().apply { cornerRadius = r; setColor(d.bg) }
        }
    }

    private fun bindIcon(a: App, iv: ImageView, h: Int, r: Float, square: Boolean) {
        iv.tag = a.pkg
        val c = iconCache[a.pkg]
        if (c != null) { showIcon(iv, c, h, r, square); return }
        iv.setImageDrawable(null)
        iv.setPadding(0, 0, 0, 0)
        iv.background = GradientDrawable().apply { cornerRadius = r; setColor(0x1AFFFFFF) }
        try {
            io.execute {
                val d = loadIconData(a)
                iconCache[a.pkg] = d
                ui.post { if (iv.tag == a.pkg) showIcon(iv, d, h, r, square) }
            }
        } catch (e: Exception) { }
    }

    private fun labelView(text: String, key: String, color: Int, pct: Int = prefs.getInt(key, 100)) = TextView(this).apply {
        this.text = text; textSize = 13f * pct / 100f
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        typeface = face()
        styleLabel(this, color)
    }

    // ================= главный экран: ячейки (отдельно для каждого блока) =================
    private fun rawSlots(b: Int): MutableList<Slot> =
        (prefs.getString(pk("slots", b), "") ?: "").split(";").mapNotNull { s ->
            val p = s.split(",")
            val r = if (p.size == 3) p[1].toIntOrNull() else null
            val c = if (p.size == 3) p[2].toIntOrNull() else null
            if (r != null && c != null && p[0].isNotEmpty()) Slot(p[0], r, c) else null
        }.toMutableList()

    private fun saveSlots(b: Int, l: List<Slot>) {
        prefs.edit().putString(pk("slots", b), l.joinToString(";") { it.pkg + "," + it.r + "," + it.c }).apply()
    }

    /** Реальная раскладка: установленные приложения; вышедшие за сетку или столкнувшиеся ставятся в свободные ячейки */
    private fun layoutSlots(b: Int): List<Slot> {
        val rows = pi("hRows", 2, b)
        val cols = pi("hCols", 6, b)
        val taken = HashSet<Int>()
        val out = ArrayList<Slot>()
        val pending = ArrayList<Slot>()
        for (s in rawSlots(b)) {
            if (!byPkg.containsKey(s.pkg)) continue
            if (s.r in 0 until rows && s.c in 0 until cols && taken.add(s.r * cols + s.c)) out.add(s) else pending.add(s)
        }
        for (s in pending) {
            loop@ for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (taken.add(r * cols + c)) { out.add(Slot(s.pkg, r, c)); break@loop }
                }
            }
        }
        return out
    }

    private fun persist(b: Int, vis: List<Slot>, drop: String?) {
        val keep = rawSlots(b).filter { s -> s.pkg != drop && vis.none { it.pkg == s.pkg } }
        saveSlots(b, vis + keep)
    }

    private fun addToHome(b: Int, pkg: String) {
        val vis = layoutSlots(b).toMutableList()
        val rows = pi("hRows", 2, b)
        val cols = pi("hCols", 6, b)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (vis.none { it.r == r && it.c == c }) {
                    vis.add(Slot(pkg, r, c))
                    persist(b, vis, null); renderFavs()
                    toast(if (split()) "Добавлено: " + winName(b) else "Добавлено на главный экран")
                    return
                }
            }
        }
        toast(if (split()) "В окне («" + winName(b) + "») нет места — увеличьте сетку в настройках" else "На главном экране нет места — увеличьте сетку в настройках")
    }

    private fun removeFromHome(b: Int, pkg: String) {
        persist(b, layoutSlots(b).filter { it.pkg != pkg }, pkg)
        renderFavs()
    }

    /** Отложенная перерисовка: при быстром движении ползунка плитки перестраиваются один раз */
    private fun renderFavsSoon() {
        ui.removeCallbacks(renderRun)
        ui.postDelayed(renderRun, 80)
    }

    private fun renderFavs() {
        if (!appsLoaded) return
        ui.removeCallbacks(renderRun)
        renderBlock(0)
        renderBlock(1)
    }

    private class Ext(val r0: Int, val r1: Int, val c0: Int, val c1: Int, val empty: Boolean, val slots: List<Slot>)

    private fun ext(b: Int): Ext {
        val rows = pi("hRows", 2, b)
        val cols = pi("hCols", 6, b)
        val slots = layoutSlots(b)
        val moving = movePkg != null && moveBlk == b
        if (slots.isEmpty() && !moving) return Ext(0, 0, 0, 0, true, slots)
        if (moving) return Ext(0, rows - 1, 0, cols - 1, false, slots)
        return Ext(slots.minOf { it.r }, slots.maxOf { it.r }, slots.minOf { it.c }, slots.maxOf { it.c }, false, slots)
    }

    private fun totalW() = resources.displayMetrics.widthPixels - dp(112)

    /** Ширина плитки в одиночном (полноэкранном) режиме */
    private fun baseW(b: Int, e: Ext): Int =
        minOf(dp(pi("hTile", 150, b)), (totalW() - dp(28)) / (e.c1 - e.c0 + 1) - dp(24)).coerceAtLeast(dp(40))

    /** Общий коэффициент (<=1), чтобы оба окна с их исходными размерами поместились на экране без наезда */
    private fun splitScale(horiz: Boolean): Float {
        val gap = dp(16)
        var fixed = 0
        var sum = 0
        for (b in 0..1) {
            val e = ext(b)
            if (e.empty) { fixed += if (horiz) dp(304) else dp(170); continue }
            val w0 = baseW(b, e)
            if (horiz) {
                val n = e.c1 - e.c0 + 1
                fixed += dp(44) + n * dp(24)
                sum += n * w0
            } else {
                val n = e.r1 - e.r0 + 1
                fixed += dp(36) + n * (dp(16) + (if (pi("hLbl", 1, b) == 1) dp(30) else 0))
                sum += n * (if (pi("hFmt", 0, b) == 1) w0 else w0 * 9 / 16)
            }
        }
        if (sum <= 0) return 1f
        val avail = if (horiz) totalW() - gap else resources.displayMetrics.heightPixels - dp(210) - gap
        return ((avail - fixed).toFloat() / sum).coerceIn(0.2f, 1f)
    }

    private fun renderBlock(b: Int) {
        val fg = favGrids[b]
        fg.removeAllViews(); favTiles[b].clear()
        val sp = split()
        if (b == 1 && !sp) { homeEmpty[1] = true; return }

        val dm = resources.displayMetrics
        val horiz = splitHoriz()
        val e = ext(b)
        val slots = e.slots
        val moving = movePkg != null && moveBlk == b
        homeEmpty[b] = e.empty
        applyFavBg(b)
        if (e.empty) {
            val nm = if (b == 0) "Первое окно" else "Второе окно"
            fg.addView(TextView(this).apply {
                tag = "hint"
                text = if (sp) "$nm пусто. Откройте «Все приложения» (значок сетки справа вверху), зажмите OK на приложении и выберите «Добавить: $nm»."
                else "Главный экран пуст. Откройте «Все приложения» (значок сетки справа вверху), зажмите OK на приложении и выберите «Добавить на главный экран»."
                textSize = 15f; setTextColor(favTxt(b)); setShadowLayer(4f, 0f, 2f, 0xCC000000.toInt())
                setPadding(dp(8), dp(8), dp(8), dp(8))
                maxWidth = if (sp) dp(260) else dm.widthPixels / 2
            })
            return
        }
        val r0 = e.r0; val r1 = e.r1; val c0 = e.c0; val c1 = e.c1
        val square = pi("hFmt", 0, b) == 1
        val showLbl = pi("hLbl", 1, b) == 1
        // размер плиток как в одиночном окне; уменьшаем только если два окна вместе не помещаются
        var w = baseW(b, e)
        if (sp) w = (w * splitScale(horiz)).toInt()
        w = w.coerceAtLeast(dp(40))
        val h = if (square) w else w * 9 / 16
        val rad = h * pi("hRad", 14, b) / 100f
        val byCell = slots.associateBy { it.r * 1000 + it.c }
        for (r in r0..r1) {
            val row = LinearLayout(this).apply { clipChildren = false; clipToPadding = false }
            for (c in c0..c1) {
                val s = byCell[r * 1000 + c]
                val app = s?.let { byPkg[it.pkg] }
                val cell = if (app != null) favTile(b, app, w, h, rad, showLbl, square)
                else emptyCell(b, w, h, rad, showLbl, moving)
                row.addView(cell, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(4); rightMargin = dp(4) })
            }
            fg.addView(row, LinearLayout.LayoutParams(-2, -2))
        }
    }

    private fun tileBg(b: Int, pkg: String, f: Boolean): Drawable? {
        val r = dp(18).toFloat()
        val ring = ringColor(favEff(b))
        if (pkg == movePkg && b == moveBlk) return GradientDrawable().apply { cornerRadius = r; setColor(alpha(accent, 0x66)); setStroke(dp(3), ring) }
        if (f) return GradientDrawable().apply { cornerRadius = r; setColor(alpha(accent, 0x30)); setStroke(dp(3), ring) }
        return null
    }

    private fun favTile(b: Int, a: App, w: Int, h: Int, r: Float, lbl: Boolean, sq: Boolean): View {
        val iv = tileImage(r)
        bindIcon(a, iv, h, r, sq)
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true; isClickable = true
            tag = a.pkg
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(iv, LinearLayout.LayoutParams(w, h))
            if (lbl) addView(labelView(a.label, pk("hTxt", b), favTxt(b), pi("hTxt", 100, b)), LinearLayout.LayoutParams(w, -2).apply { topMargin = dp(6) })
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.08f else 1f).scaleY(if (f) 1.08f else 1f).setDuration(110).start()
                v.background = tileBg(b, a.pkg, f)
                if (f) { lastPkg = a.pkg; lastBlk = b }
            }
            setOnClickListener { launch(a, true, b) }
            setOnLongClickListener { appMenu(a); true }
        }
        t.background = tileBg(b, a.pkg, false)
        favTiles[b][a.pkg] = t
        return t
    }

    private fun emptyCell(b: Int, w: Int, h: Int, r: Float, lbl: Boolean, visible: Boolean): View {
        val iv = ImageView(this)
        if (visible) iv.background = GradientDrawable().apply {
            cornerRadius = r; setColor(0x22FFFFFF); setStroke(dp(2), 0x44FFFFFF)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(iv, LinearLayout.LayoutParams(w, h))
            if (lbl) addView(labelView(" ", pk("hTxt", b), Color.WHITE, pi("hTxt", 100, b)), LinearLayout.LayoutParams(w, -2).apply { topMargin = dp(6) })
            visibility = if (visible) View.VISIBLE else View.INVISIBLE
        }
    }

    // ----- свободное перемещение по сетке (внутри своего блока) -----
    private fun startMove(b: Int, pkg: String) {
        closeLayers()
        if (layoutSlots(b).none { it.pkg == pkg }) { toast("Приложения нет на главном экране"); return }
        movePkg = pkg; moveBlk = b
        renderFavs()
        favTiles[b][pkg]?.requestFocus()
        toast("Стрелки — переместить в любую ячейку, OK — готово")
    }

    private fun moveStep(dr: Int, dc: Int) {
        val p = movePkg ?: return
        val b = moveBlk
        val vis = layoutSlots(b).toMutableList()
        val s = vis.firstOrNull { it.pkg == p } ?: return
        val nr = s.r + dr
        val nc = s.c + dc
        if (nr < 0 || nr >= pi("hRows", 2, b) || nc < 0 || nc >= pi("hCols", 6, b)) return
        val other = vis.firstOrNull { it.r == nr && it.c == nc }
        if (other != null) { other.r = s.r; other.c = s.c }
        s.r = nr; s.c = nc
        persist(b, vis, null)
        renderFavs()
        favTiles[b][p]?.requestFocus()
    }

    private fun endMove() {
        val p = movePkg
        val b = moveBlk
        movePkg = null
        renderFavs()
        if (p != null) favTiles[b][p]?.requestFocus()
    }

    private fun reorderFromSettings(b: Int) {
        val first = layoutSlots(b).sortedWith(compareBy<Slot>({ it.r }, { it.c })).firstOrNull()
        if (first == null) { toast(if (split()) "В окне («" + winName(b) + "») нет приложений" else "Главный экран пуст"); return }
        startMove(b, first.pkg)
    }

    // ================= меню «Все приложения» =================
    private fun showApps() {
        layer = 1
        settingsLayer.visibility = View.GONE
        fadeIn(appsLayer)
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        applyAppsBg()
        val dm = resources.displayMetrics
        val cw = dm.widthPixels * prefs.getInt("aWin", 80) / 100
        val ch = dm.heightPixels * prefs.getInt("aWinH", 80) / 100
        val gx = when (prefs.getInt("aPos", 1)) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        appsCard.layoutParams = FrameLayout.LayoutParams(cw, ch, gx or Gravity.CENTER_VERTICAL).apply {
            leftMargin = dp(32); rightMargin = dp(32)
        }
        val cols = prefs.getInt("aCols", 6).coerceAtLeast(1)
        val avail = cw - dp(48) - dp(16)
        aSq = prefs.getInt("aFmt", 0) == 1
        aW = minOf(dp(prefs.getInt("aTile", 140)), avail / cols - dp(20)).coerceAtLeast(dp(40))
        aH = if (aSq) aW else aW * 9 / 16
        aRad = aH * prefs.getInt("aRad", 14) / 100f
        grid.numColumns = cols
        grid.selector = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat(); setColor(alpha(accent, 0x30)); setStroke(dp(3), ringColor(appsEff()))
        }
        grid.adapter = appsAdapter
        val i = apps.indexOfFirst { it.pkg == lastAppsPkg }
        if (i >= 0) grid.setSelection(i)
        grid.requestFocus()
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int): Any = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val a = apps[p]
            val v = (cv ?: cell()) as LinearLayout
            val tv = v.getChildAt(1) as TextView
            tv.text = a.label
            tv.typeface = face()
            styleLabel(tv, appsTxt())
            bindIcon(a, v.getChildAt(0) as ImageView, aH, aRad, aSq)
            return v
        }
    }

    private fun cell(): LinearLayout {
        val iv = tileImage(aRad)
        val tv = labelView("", "aTxt", appsTxt())
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(8), dp(6), dp(6))
            addView(iv, LinearLayout.LayoutParams(aW, aH))
            addView(tv, LinearLayout.LayoutParams(aW, -2).apply { topMargin = dp(6) })
        }
    }

    // ================= настройки: каркас страниц =================
    /** back = страница-родитель; null — корень настроек (Back закрывает панель) */
    private fun openPage(back: (() -> Unit)?) {
        layer = if (back == null) 2 else 3
        val closer: () -> Unit = { closeLayers() }
        backTarget = back ?: closer
        appsLayer.visibility = View.GONE
        fadeIn(settingsLayer)
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        panel.removeAllViews()
        themed.clear()
        applyPanelBg()
    }

    // ----- главная страница настроек -----
    private fun showSettings() {
        openPage(null)
        panelTitle("Настройки")
        section("ВНЕШНИЙ ВИД")
        menuRow("Оформление", "›") { showDesign() }
        section("СИСТЕМА")
        menuRow("Настройки Android", "›") { openSystemSettings() }
        menuRow("Проверить обновления", "›") { checkUpdate() }
        menuRow("Сбросить всё", null) { confirmReset() }
        menuRow("Закрыть", null) { closeLayers() }
        aboutBlock()
        panel.requestFocus()
    }

    /** О приложении: название -> ссылки -> версия */
    private fun aboutBlock() {
        panel.addView(View(this).apply { setBackgroundColor(0x22FFFFFF) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(14); bottomMargin = dp(12) })
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        titleRow.addView(TextView(this).apply {
            text = "J.Launcher"; textSize = 20f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        titleRow.addView(TextView(this).apply {
            text = "for AndroidTV"; textSize = 12f; setTextColor(col("#8493A6")); setPadding(dp(8), 0, 0, 0)
        })
        box.addView(titleRow, LinearLayout.LayoutParams(-2, -2))
        val links = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        links.addView(linkView("GitHub", "https://github.com/josywtf-gif/J.Launcher"),
            LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        links.addView(linkView("4PDA", "https://4pda.to/forum/index.php?showuser=11268484"),
            LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        links.addView(linkView("Telegram", "https://t.me/josywtf"), LinearLayout.LayoutParams(-2, -2))
        box.addView(links, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        box.addView(TextView(this).apply {
            text = "Версия $ver"; textSize = 14f; setTextColor(col("#9FB0C3")); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
        panel.addView(box, LinearLayout.LayoutParams(-1, -2))
    }

    private fun linkView(title: String, url: String): TextView {
        val tv = TextView(this)
        fun paint(f: Boolean) {
            tv.setTextColor(if (f) onAccent(accent) else mix(Color.WHITE, accent, 0.4f))
            tv.background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(if (f) accent else 0x1AFFFFFF) }
        }
        tv.apply {
            text = title; textSize = 17f
            setPadding(dp(14), dp(8), dp(14), dp(8))
            isFocusable = true; isClickable = true
            setOnFocusChangeListener { _, f -> paint(f) }
            setOnClickListener {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { toast("Не удалось открыть ссылку") }
            }
        }
        paint(false)
        themed.add { paint(tv.isFocused) }
        return tv
    }

    // ----- Оформление -----
    private fun showDesign() {
        openPage { showSettings() }
        panelTitle("Оформление")
        menuRow("Строка состояния", "›") { showStatus() }
        menuRow("Темы", "›") { showThemes() }
        menuRow("Все приложения", "›") { showAppsMenu() }
        menuRow("Первое окно приложений", "›") { showWindow(0) }
        menuRow("Второе окно приложений", if (split()) "Вкл" else "Выкл") { showWindow(1) }
        menuRow("Назад", null) { showSettings() }
        panel.requestFocus()
    }

    // ----- Оформление -> Темы: палитра/акценты, прозрачность системы, обои, шрифт -----
    private fun showThemes() {
        openPage { showDesign() }
        panelTitle("Темы")
        section("ГОТОВЫЕ ТЕМЫ (ФОН + АКЦЕНТ)")
        val cards = themes.map { themeCard(it) }
        addSwatches(cards, 4, dp(104), dp(70))
        section("ЦВЕТ АКЦЕНТА (ВЕСЬ ИНТЕРФЕЙС)")
        val accents = listOf("#3D8BFF", "#00BCD4", "#1DE9B6", "#4CAF50", "#C6FF00", "#FFD600",
            "#FF9100", "#FF5252", "#FF4081", "#E040FB", "#7C4DFF", "#FFFFFF").map { col(it) }
        val views = accents.map { c -> swatch(intArrayOf(c)) { setAccent(c) } }
        addSwatches(views, 6, dp(64), dp(44))
        val hsv = FloatArray(3)
        Color.colorToHSV(accent, hsv)
        slider("Свой оттенок", 0, 360, hsv[0].toInt(), 8, { "$it°" }) { p ->
            setAccent(Color.HSVToColor(floatArrayOf(p.toFloat(), 0.75f, 1f)))
        }
        section("ПРОЗРАЧНОСТЬ СИСТЕМЫ")
        slider("Прозрачность панели настроек", 0, 70, 100 - prefs.getInt("panelOp", 96).coerceIn(30, 100), 5, { "$it%" }) { p ->
            prefs.edit().putInt("panelOp", 100 - p).apply(); applyPanelBg()
        }
        section("ОБОИ")
        slider("Затемнение обоев", 0, 80, prefs.getInt("dim", 40), 5, { "$it%" }) { p ->
            prefs.edit().putInt("dim", p).apply(); applyDim()
        }
        menuRow("Своя картинка из файла", null) { pickImage() }
        menuRow("Картинка по ссылке", null) { askUrl() }
        section("ШРИФТ")
        choice("Шрифт (подписи, часы, меню)", arrayOf("Обычный", "Тонкий", "Узкий", "Serif"), "font", 0) { applyFont() }
        menuRow("Назад", null) { showDesign() }
        cards[0].requestFocus()
    }

    // ----- Оформление -> Первое / Второе окно приложений (b = 0 / 1) -----
    private fun showWindow(b: Int) {
        openPage { showDesign() }
        panelTitle(if (b == 0) "Первое окно приложений" else "Второе окно приложений")
        if (b == 1) {
            choice("Второе окно", arrayOf("Выкл", "Вкл"), "split", 0) {
                applySplit(); renderFavs(); showWindow(1)
            }
            if (!split()) {
                menuRow("Назад", null) { showDesign() }
                panel.requestFocus()
                return
            }
        }
        if (split()) {
            choice("Расположение окон", arrayOf("Авто", "Рядом", "Друг под другом"), "splitDir", 0) {
                applySplit(); renderFavs()
            }
        }
        menuRow("Расставить приложения", "›") { reorderFromSettings(b) }
        menuRow("Сетка и размеры", "›") { showWindowSizes(b) }
        menuRow("Цвет и фон окна", "›") { showWindowColors(b) }
        menuRow("Назад", null) { showDesign() }
        panel.requestFocus()
    }

    private fun showWindowSizes(b: Int) {
        openPage { showWindow(b) }
        panelTitle("Сетка и размеры — " + winName(b))
        section("СЕТКА")
        choice("Расположение значков", arrayOf("Слева", "По центру", "Справа"), pk("hAlign", b), 1) { applyAlign() }
        prefSlider("Строки", pk("hRows", b), 2, 1, 6, 1, "") { renderFavsSoon() }
        prefSlider("Столбцы", pk("hCols", b), 6, 1, 12, 1, "") { renderFavsSoon() }
        section("ПЛИТКИ")
        choice("Формат", arrayOf("Плитки 16:9", "Квадрат"), pk("hFmt", b), 0) { renderFavs() }
        prefSlider("Размер плиток", pk("hTile", b), 150, 80, 300, 10, " dp") { renderFavsSoon() }
        prefSlider("Размер текста", pk("hTxt", b), 100, 60, 200, 10, "%") { renderFavsSoon() }
        prefSlider("Скругление углов", pk("hRad", b), 14, 0, 50, 2, "%") { renderFavsSoon() }
        choice("Подписи", arrayOf("Скрыть", "Показать"), pk("hLbl", b), 1) { renderFavs() }
        menuRow("Назад", null) { showWindow(b) }
        panel.requestFocus()
    }

    /** Цвет и прозрачность фона окна b: ключи favBg/favOp (окно 1) и favBg2/favOp2 (окно 2) — независимы */
    private fun showWindowColors(b: Int) {
        openPage { showWindow(b) }
        panelTitle("Цвет и фон — " + winName(b))
        section("ЦВЕТ ФОНА")
        val bgs = listOf("#000000", "#10141C", "#1B2230", "#FFFFFF", "#3D8BFF",
            "#7C4DFF", "#FF5252", "#4CAF50", "#FFD600", "#FF9100").map { col(it) }
        val bgViews = bgs.map { c -> swatch(intArrayOf(c)) { prefs.edit().putInt(pk("favBg", b), c).apply(); applyFavBg(b) } }
        addSwatches(bgViews, 5, dp(80), dp(44))
        section("ПРОЗРАЧНОСТЬ")
        slider("Прозрачность", 0, 100, 100 - pi("favOp", favOpDef(b), b), 5, { "$it%" }) { p ->
            prefs.edit().putInt(pk("favOp", b), 100 - p).apply(); applyFavBg(b)
        }
        menuRow("Назад", null) { showWindow(b) }
        bgViews[0].requestFocus()
    }

    // ----- Оформление -> Строка состояния -----
    private fun showStatus() {
        openPage { showDesign() }
        panelTitle("Строка состояния")
        menuRow("Настройка часов", "›") { showClockSettings() }
        menuRow("Настройка ВПН", "›") { showVpnSettings() }
        menuRow("Значки настроек и меню приложений", "›") { showIconSettings() }
        menuRow("Назад", null) { showDesign() }
        panel.requestFocus()
    }

    private fun showClockSettings() {
        openPage { showStatus() }
        panelTitle("Настройка часов")
        choice("Часы", arrayOf("Скрыть", "Показать"), "clkShow", 1) { applyClock() }
        choice("Дата", arrayOf("Скрыть", "Показать"), "dateShow", 1) { applyClock() }
        choice("Формат времени", arrayOf("12 часов", "24 часа"), "clk24", 1) { applyClock() }
        choice("Секунды", arrayOf("Нет", "Да"), "clkSec", 0) { applyClock() }
        prefSlider("Размер часов и даты", "clkPct", 100, 60, 250, 10, "%") { applyClock() }
        menuRow("Назад", null) { showStatus() }
        panel.requestFocus()
    }

    private fun showVpnSettings() {
        openPage { showStatus() }
        panelTitle("Настройка ВПН")
        choice("Показ кнопки", arrayOf("Скрыть", "Всегда", "Когда включён"), "vpnShow", 1) { updateVpn() }
        choice("Действие по нажатию", arrayOf("Настройки VPN", "Приложение", "Свой intent"), "vpnAct", 0) { }
        val appName = byPkg[prefs.getString("vpnPkg", "") ?: ""]?.label ?: "не выбрано"
        val appRow = menuRow("Приложение VPN", appName) { }
        appRow.setOnClickListener {
            val list = apps
            AlertDialog.Builder(this).setTitle("Приложение VPN")
                .setItems(list.map { it.label }.toTypedArray()) { _, w ->
                    prefs.edit().putString("vpnPkg", list[w].pkg).apply()
                    (appRow.tag as TextView).text = list[w].label
                }.show()
        }
        menuRow("Свой intent (включить / выключить)", "›") { showVpnIntent() }
        menuRow("Назад", null) { showStatus() }
        panel.requestFocus()
    }

    private fun showVpnIntent() {
        openPage { showVpnSettings() }
        panelTitle("Свой intent для VPN")
        panel.addView(label("Если VPN выключен, по нажатию отправляется действие «включить»; если включён — «выключить». Если «выключить» пусто, отправляется то же действие (переключатель)."))
        choice("Способ отправки", arrayOf("Broadcast", "Activity", "Service"), "vpnType", 0) { }
        editRow("Действие «включить»", "vpnOnAct", "com.example.action.ON", "не задано")
        editRow("Действие «выключить»", "vpnOffAct", "com.example.action.OFF", "как «включить»")
        editRow("Пакет приложения", "vpnIPkg", "com.example.vpn", "не задан")
        editRow("Параметры (ключ=значение;…)", "vpnIExtra", "tunnel=wg0", "нет")
        menuRow("Шаблон: WireGuard", "›") { wireguardPreset() }
        menuRow("Назад", null) { showVpnSettings() }
        panel.requestFocus()
    }

    private fun showIconSettings() {
        openPage { showStatus() }
        panelTitle("Значки настроек и меню приложений")
        prefSlider("Размер значков (VPN, приложения, настройки)", "btnDp", 56, 40, 110, 4, " dp") { applyBtnSize() }
        menuRow("Назад", null) { showStatus() }
        panel.requestFocus()
    }

    /** Строка с текстовым значением: по нажатию открывается ввод */
    private fun editRow(title: String, key: String, hint: String, empty: String) {
        val cur = { prefs.getString(key, "") ?: "" }
        val row = menuRow(title, cur().ifEmpty { empty }) { }
        row.setOnClickListener {
            val et = EditText(this).apply { setText(cur()); this.hint = hint; setSingleLine() }
            AlertDialog.Builder(this).setTitle(title).setView(et)
                .setPositiveButton("Сохранить") { _, _ ->
                    val t = et.text.toString().trim()
                    prefs.edit().putString(key, t).apply()
                    (row.tag as TextView).text = if (t.isEmpty()) empty else t
                }.setNegativeButton("Отмена", null).show()
        }
    }

    private fun wireguardPreset() {
        val et = EditText(this).apply { hint = "Имя туннеля (как в WireGuard)"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Шаблон WireGuard").setView(et)
            .setPositiveButton("Применить") { _, _ ->
                prefs.edit()
                    .putInt("vpnType", 0).putInt("vpnAct", 2)
                    .putString("vpnOnAct", "com.wireguard.android.action.SET_TUNNEL_UP")
                    .putString("vpnOffAct", "com.wireguard.android.action.SET_TUNNEL_DOWN")
                    .putString("vpnIPkg", "com.wireguard.android")
                    .putString("vpnIExtra", "tunnel=" + et.text.toString().trim())
                    .apply()
                if (Build.VERSION.SDK_INT >= 23) {
                    try { requestPermissions(arrayOf("com.wireguard.android.permission.CONTROL_TUNNELS"), 9) } catch (e: Exception) { }
                }
                toast("Шаблон применён. В WireGuard разрешите управление из других приложений")
                showVpnIntent()
            }.setNegativeButton("Отмена", null).show()
    }

    // ----- меню всех приложений -----
    private fun showAppsMenu() {
        openPage { showDesign() }
        panelTitle("Все приложения")
        section("ОКНО")
        choice("Положение окна", arrayOf("Слева", "По центру", "Справа"), "aPos", 1) { }
        prefSlider("Ширина окна", "aWin", 80, 40, 100, 5, "%") { }
        prefSlider("Высота окна", "aWinH", 80, 40, 100, 5, "%") { }
        section("СЕТКА И ПЛИТКИ")
        choice("Формат", arrayOf("Плитки 16:9", "Квадрат"), "aFmt", 0) { }
        prefSlider("Столбцы", "aCols", 6, 3, 10, 1, "") { }
        prefSlider("Размер плиток", "aTile", 140, 80, 260, 10, " dp") { }
        prefSlider("Размер текста", "aTxt", 100, 60, 200, 10, "%") { }
        prefSlider("Скругление углов", "aRad", 14, 0, 50, 2, "%") { }
        section("ФОН ОКНА")
        val bgs = listOf("#0B0F16", "#000000", "#1B2230", "#2B1B3D", "#0B3B2E", "#3B0B1A", "#FFFFFF", "#3D8BFF", "#7C4DFF", "#FF9100").map { col(it) }
        val bgViews = bgs.map { c -> swatch(intArrayOf(c)) { prefs.edit().putInt("aBg", c).apply(); applyAppsBg() } }
        addSwatches(bgViews, 5, dp(80), dp(44))
        slider("Прозрачность фона", 0, 100, 100 - prefs.getInt("aOp", 93), 5, { "$it%" }) { p ->
            prefs.edit().putInt("aOp", 100 - p).apply(); applyAppsBg()
        }
        menuRow("Открыть меню приложений", "›") { showApps() }
        menuRow("Назад", null) { showDesign() }
        panel.requestFocus()
    }

    /** Проверка обновлений: последний релиз GitHub (тег v<номер сборки>) сравнивается с текущей версией 1.<номер> */
    private fun checkUpdate() {
        toast("Проверка обновлений…")
        val cur = (try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" })
            .substringAfter('.').toIntOrNull() ?: 0
        io.execute {
            try {
                val c = java.net.URL("https://api.github.com/repos/josywtf-gif/J.Launcher/releases/latest")
                    .openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 10000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val j = JSONObject(c.inputStream.use { String(it.readBytes()) })
                val remote = j.optString("tag_name", "").trimStart('v', 'V').substringAfter('.').toIntOrNull() ?: 0
                var url = j.optString("html_url", "https://github.com/josywtf-gif/J.Launcher/releases")
                val assets = j.optJSONArray("assets")
                if (assets != null) for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url", url); break }
                }
                ui.post {
                    if (isFinishing) return@post
                    if (remote > cur) {
                        val u = url
                        themedDialog("Доступно обновление", "Версия 1.$remote (у вас 1.$cur)", null,
                            listOf("Скачать" to { startUpdate(u) }, "Позже" to { })).show()
                    } else toast("Установлена последняя версия")
                }
            } catch (e: Throwable) { ui.post { toast("Не удалось проверить обновления") } }
        }
    }

    // ================= обновление: скачивание внутри приложения + установка =================
    @Volatile private var dlCancel = false
    private var installPending = false

    private fun updDir() = File(cacheDir, "updates")

    private fun cleanUpdates() {
        try { updDir().listFiles()?.forEach { it.delete() } } catch (e: Exception) { }
    }

    private fun dlgButton(text: String, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        fun paint(f: Boolean) {
            tv.setTextColor(if (f) onAccent(accent) else Color.WHITE)
            tv.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(if (f) accent else 0x1AFFFFFF) }
        }
        tv.apply {
            this.text = text; textSize = 17f; gravity = Gravity.CENTER
            setPadding(dp(20), dp(12), dp(20), dp(12))
            isFocusable = true; isClickable = true
            setOnFocusChangeListener { _, f -> paint(f) }
            setOnClickListener { onClick() }
        }
        paint(false)
        return tv
    }

    /** Диалог в стиле текущей темы: фон панели настроек, обводка и кнопки в цвете акцента */
    private fun themedDialog(title: String, msg: String?, extra: ((LinearLayout) -> Unit)?,
                             btns: List<Pair<String, () -> Unit>>, onCancel: (() -> Unit)? = null): Dialog {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(20))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(alpha(panelColor(), 0xF5))
                setStroke(dp(2), alpha(accent, 0x55))
            }
        }
        box.addView(TextView(this).apply { text = title; textSize = 22f; setTextColor(Color.WHITE); typeface = face() })
        if (msg != null) box.addView(TextView(this).apply {
            text = msg; textSize = 16f; setTextColor(col("#C9D6E4")); setPadding(0, dp(10), 0, 0)
        })
        extra?.invoke(box)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        var first: View? = null
        btns.forEach { (name, act) ->
            val b = dlgButton(name) { d.dismiss(); act() }
            if (first == null) first = b
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(10) })
        }
        box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        d.setContentView(box, ViewGroup.LayoutParams(dp(460), -2))
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.setOnCancelListener { onCancel?.invoke() }
        d.setOnShowListener { first?.requestFocus() }
        return d
    }

    private fun askInstallPermission() {
        themedDialog("Установка запрещена",
            "Разрешите установку из неизвестных источников для J.Launcher в настройках, затем повторите проверку обновлений.", null,
            listOf("Открыть настройки" to {
                try {
                    if (Build.VERSION.SDK_INT >= 26) startActivity(
                        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    else openSystemSettings()
                } catch (e: Exception) { openSystemSettings() }
            }, "Закрыть" to { })).show()
    }

    private fun startUpdate(url: String) {
        if (!url.endsWith(".apk", true)) { toast("В релизе нет APK-файла"); return }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) { askInstallPermission(); return }
        cleanUpdates()
        val dir = updDir(); dir.mkdirs()
        val f = File(dir, "update.apk")
        dlCancel = false
        val pct = TextView(this).apply {
            text = "Загрузка обновления... 0%"; textSize = 17f; setTextColor(Color.WHITE)
            setPadding(0, dp(16), 0, dp(8))
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        }
        val cancel = {
            dlCancel = true
            cleanUpdates()
        }
        val dlg = themedDialog("Обновление", null, { box ->
            box.addView(pct, LinearLayout.LayoutParams(-1, -2))
            box.addView(bar, LinearLayout.LayoutParams(-1, dp(12)))
        }, listOf("Отмена" to { cancel() }), { cancel() })
        dlg.show()
        Thread {
            var ok = false
            try {
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 20000
                val total = c.contentLength
                if (total <= 0) ui.post { bar.isIndeterminate = true }
                c.inputStream.use { inp ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(32768)
                        var done = 0L
                        var last = -1
                        while (!dlCancel) {
                            val n = inp.read(buf)
                            if (n < 0) { ok = true; break }
                            out.write(buf, 0, n); done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt().coerceIn(0, 100)
                                if (p != last) { last = p; ui.post { bar.progress = p; pct.text = "Загрузка обновления... $p%" } }
                            }
                        }
                    }
                }
            } catch (e: Throwable) { ok = false }
            ui.post {
                if (dlCancel) { cleanUpdates(); return@post }
                if (isFinishing) return@post
                dlg.dismiss()
                if (ok) installApk(f) else { cleanUpdates(); toast("Не удалось скачать обновление") }
            }
        }.apply { isDaemon = true; start() }
    }

    private fun installApk(f: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            installPending = true
            startActivity(i)
        } catch (e: SecurityException) {
            installPending = false; cleanUpdates(); askInstallPermission()
        } catch (e: Exception) {
            installPending = false; cleanUpdates(); toast("Не удалось запустить установщик")
        }
    }

    private fun openSystemSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Не удалось открыть настройки системы") }
    }

    private fun setAccent(c: Int) {
        accent = c
        prefs.edit().putInt("accent", c).apply()
        applyAccent()
    }

    private fun applyThemePreset(t: Theme) {
        accent = t.accent
        prefs.edit().putInt("accent", t.accent).putString("wp_type", "grad").putString("wp_c", t.bg.joinToString(","))
            .putInt("favBg", t.bg[1]).putInt("favBg2", t.bg[2]).putInt("aBg", t.bg[0]).apply()
        applyWallpaper()
        applyAppsBg()
        applyAccent() // панель настроек, кнопки и плитки перекрашиваются вместе с темой
        toast("Тема: " + t.name)
    }

    // ----- безопасный сброс: 5 секунд до активации кнопки «Согласен» -----
    private fun confirmReset() {
        val total = 5000
        val msg = TextView(this).apply {
            text = "Все настройки, раскладка главного экрана и обои будут удалены без возможности восстановления."
            textSize = 16f
        }
        val sec = TextView(this).apply {
            textSize = 22f; gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(8))
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = total; progress = 0; progressTintList = ColorStateList.valueOf(accent)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), 0)
            addView(msg, LinearLayout.LayoutParams(-1, -2))
            addView(sec, LinearLayout.LayoutParams(-1, -2))
            addView(bar, LinearLayout.LayoutParams(-1, -2))
        }
        val dlg = AlertDialog.Builder(this).setTitle("Сбросить всё?").setView(box)
            .setPositiveButton("Согласен") { _, _ -> resetAll() }
            .setNegativeButton("Отмена", null).create()
        val t0 = SystemClock.elapsedRealtime()
        val tick = object : Runnable {
            override fun run() {
                val e = (SystemClock.elapsedRealtime() - t0).toInt().coerceIn(0, total)
                bar.progress = e
                if (e >= total) {
                    sec.text = "Можно подтвердить"
                    dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled = true
                } else {
                    sec.text = "Подождите: " + ((total - e + 999) / 1000) + " с"
                    ui.postDelayed(this, 50)
                }
            }
        }
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled = false
            dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.requestFocus()
            ui.post(tick)
        }
        dlg.setOnDismissListener { ui.removeCallbacks(tick) }
        dlg.show()
    }

    private fun resetAll() {
        ui.removeCallbacks(renderRun)
        prefs.edit().clear().apply()
        File(filesDir, "wallpaper.jpg").delete()
        movePkg = null; moveBlk = 0; lastPkg = null; lastBlk = 0; lastAppsPkg = null
        accent = themes[0].accent
        applyWallpaper(); applyDim(); applyClock(); applyBtnSize(); applySplit(); applyAppsBg(); applyFont(); updateVpn()
        renderFavs(); applyFavBg(); applyAccent(); showSettings()
        toast("Сброшено")
    }

    // ================= обои =================
    private fun applyWallpaper() {
        val token = ++wpToken
        if (prefs.getString("wp_type", "grad") == "image") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) {
                try {
                    io.execute {
                        val bmp = try { BitmapFactory.decodeFile(f.path) } catch (e: Throwable) { null }
                        if (bmp != null) ui.post {
                            if (token == wpToken) { wall.background = null; wall.setImageBitmap(bmp) }
                        }
                    }
                } catch (e: Exception) { }
                return
            }
        }
        val c = wpColors()
        val arr = if (c.size >= 2) c.toIntArray() else intArrayOf(c[0], c[0])
        wall.setImageDrawable(null)
        wall.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, arr)
    }

    private fun pickImage() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 7)
        } catch (e: Exception) { toast("На этом ТВ нет выбора файлов — используйте ссылку") }
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (rc == 7 && res == RESULT_OK) io.execute {
            try { contentResolver.openInputStream(u)!!.use { saveWallpaper(it.readBytes()) } }
            catch (e: Throwable) { ui.post { toast("Не удалось загрузить картинку") } }
        }
    }

    private fun askUrl() {
        val et = EditText(this).apply { hint = "https://..."; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Ссылка на картинку").setView(et)
            .setPositiveButton("Загрузить") { _, _ ->
                val u = et.text.toString().trim()
                toast("Загрузка…")
                io.execute {
                    try {
                        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 8000; c.readTimeout = 15000
                        saveWallpaper(c.inputStream.use { it.readBytes() })
                    } catch (e: Throwable) { ui.post { toast("Не удалось загрузить") } }
                }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun saveWallpaper(b: ByteArray) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 1920) s *= 2
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            ?: throw IllegalStateException("bad image")
        File(filesDir, "wallpaper.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        prefs.edit().putString("wp_type", "image").apply()
        ui.post { applyWallpaper(); applyAccent(); toast("Обои установлены") }
    }

    // ================= элементы меню =================
    private fun panelTitle(t: String) {
        panel.addView(TextView(this).apply {
            text = t; textSize = 24f; setTextColor(Color.WHITE); setPadding(dp(4), 0, 0, dp(8))
        })
    }

    private fun secColor() = mix(Color.WHITE, accent, 0.35f)

    private fun section(t: String) {
        val tv = TextView(this).apply {
            text = t; textSize = 12f; letterSpacing = 0.12f; setTextColor(secColor())
            setPadding(dp(6), dp(12), 0, dp(6))
        }
        panel.addView(tv)
        themed.add { tv.setTextColor(secColor()) }
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 15f; setTextColor(col("#C9D6E4")); setPadding(dp(6), dp(6), 0, dp(2))
    }

    private fun rowBg(f: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(16).toFloat(); setColor(if (f) accent else 0x1AFFFFFF)
    }

    /** Строка меню: название слева, значение или › справа. Фокус = акцентная заливка с читаемым текстом */
    private fun menuRow(title: String, value: String?, onClick: () -> Unit): LinearLayout {
        val t = TextView(this).apply { text = title; textSize = 18f; setTextColor(Color.WHITE) }
        val v = TextView(this).apply {
            text = value ?: ""; textSize = 17f; setTextColor(col("#B3C2D3"))
            maxWidth = dp(200); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isFocusable = true; isClickable = true
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            addView(v, LinearLayout.LayoutParams(-2, -2))
        }
        fun paint(f: Boolean) {
            row.background = rowBg(f)
            t.setTextColor(if (f) onAccent(accent) else Color.WHITE)
            v.setTextColor(if (f) onAccent(accent) else col("#B3C2D3"))
        }
        row.tag = v
        paint(false)
        row.setOnFocusChangeListener { _, f ->
            paint(f)
            row.animate().scaleX(if (f) 1.02f else 1f).scaleY(if (f) 1.02f else 1f).setDuration(110).start()
        }
        row.setOnClickListener { onClick() }
        themed.add { paint(row.isFocused) }
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        return row
    }

    /** Переключатель из нескольких вариантов в одну строку (выбранный подсвечен акцентом) */
    private fun choice(title: String, opts: Array<String>, key: String, def: Int, onChange: () -> Unit) {
        panel.addView(label(title))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btns = ArrayList<TextView>()
        fun repaint() {
            val cur = prefs.getInt(key, def)
            btns.forEachIndexed { i, b ->
                val sel = i == cur
                b.background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(if (sel) accent else 0x1AFFFFFF)
                    setStroke(if (b.isFocused) dp(3) else 0, Color.WHITE)
                }
                b.setTextColor(if (sel) onAccent(accent) else Color.WHITE)
            }
        }
        opts.forEachIndexed { i, name ->
            val b = TextView(this).apply {
                text = name; textSize = 16f; gravity = Gravity.CENTER
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(6), dp(12), dp(6), dp(12))
                isFocusable = true; isClickable = true
                setOnFocusChangeListener { _, _ -> repaint() }
                setOnClickListener { prefs.edit().putInt(key, i).apply(); repaint(); onChange() }
            }
            btns.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        }
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        repaint()
        themed.add { repaint() }
    }

    /** Ползунок: влево/вправо на пульте меняют значение */
    private fun slider(title: String, lo: Int, hi: Int, value: Int, step: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): SeekBar {
        val tl = label(title + ": " + fmt(value))
        panel.addView(tl)
        val sb = SeekBar(this).apply {
            this.max = hi - lo
            keyProgressIncrement = step
            progress = value - lo
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) { val v = p + lo; tl.text = title + ": " + fmt(v); onChange(v) }
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        panel.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2); bottomMargin = dp(10) })
        themed.add {
            sb.progressTintList = ColorStateList.valueOf(accent)
            sb.thumbTintList = ColorStateList.valueOf(accent)
        }
        return sb
    }

    private fun prefSlider(title: String, key: String, def: Int, min: Int, max: Int, step: Int, suffix: String, onChange: () -> Unit) {
        slider(title, min, max, prefs.getInt(key, def).coerceIn(min, max), step, { it.toString() + suffix }) { v ->
            prefs.edit().putInt(key, v).apply(); onChange()
        }
    }

    private fun addSwatches(v: List<View>, per: Int, w: Int, h: Int) {
        v.chunked(per).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { r.addView(it, LinearLayout.LayoutParams(w, h).apply { rightMargin = dp(8); bottomMargin = dp(8) }) }
            panel.addView(r)
        }
    }

    private fun swatch(colors: IntArray, onClick: () -> Unit): View {
        val v = View(this)
        val cs = if (colors.size == 1) intArrayOf(colors[0], colors[0]) else colors
        fun bg(f: Boolean) = GradientDrawable(GradientDrawable.Orientation.TL_BR, cs).apply {
            cornerRadius = dp(14).toFloat(); setStroke(if (f) dp(3) else 0, Color.WHITE)
        }
        v.background = bg(false)
        v.isFocusable = true; v.isClickable = true
        v.setOnFocusChangeListener { _, f ->
            v.background = bg(f)
            v.animate().scaleX(if (f) 1.08f else 1f).scaleY(if (f) 1.08f else 1f).setDuration(110).start()
        }
        v.setOnClickListener { onClick() }
        return v
    }

    private fun themeCard(t: Theme): View {
        val fl = FrameLayout(this)
        fun bg(f: Boolean) = GradientDrawable(GradientDrawable.Orientation.TL_BR, t.bg).apply {
            cornerRadius = dp(14).toFloat(); setStroke(if (f) dp(3) else dp(1), if (f) Color.WHITE else 0x33FFFFFF)
        }
        fl.background = bg(false)
        fl.isFocusable = true; fl.isClickable = true
        fl.addView(TextView(this).apply {
            text = t.name; textSize = 13f; setTextColor(Color.WHITE)
            setShadowLayer(3f, 0f, 1f, 0xCC000000.toInt())
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(10); bottomMargin = dp(8) })
        fl.addView(View(this).apply {
            background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(t.accent) }
        }, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP or Gravity.END).apply { topMargin = dp(8); rightMargin = dp(8) })
        fl.setOnFocusChangeListener { v, f ->
            v.background = bg(f)
            v.animate().scaleX(if (f) 1.06f else 1f).scaleY(if (f) 1.06f else 1f).setDuration(110).start()
        }
        fl.setOnClickListener { applyThemePreset(t) }
        return fl
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
