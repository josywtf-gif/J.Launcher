package com.fast.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.ResolveInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

private fun col(s: String) = Color.parseColor(s)
private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

/** Цвет текста поверх акцента: тёмный на светлом, белый на тёмном */
private fun onAccent(c: Int): Int {
    val l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
    return if (l > 0.6) 0xFF111111.toInt() else Color.WHITE
}

class MainActivity : Activity() {

    private class App(val pkg: String, val label: String, val ri: ResolveInfo, val cat: String)
    private class Theme(val name: String, val bg: IntArray, val accent: Int)
    private class Slot(val pkg: String, var r: Int, var c: Int)
    private class IconData(val banner: Drawable?, val icon: Drawable, val bg: Int)

    /** Кнопка-иконка: kind 0 = шестерёнка, 1 = сетка «все приложения» */
    private class IconBtn(c: Context, private val kind: Int, private val accentOf: () -> Int) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        init {
            isFocusable = true; isClickable = true
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.12f else 1f).scaleY(if (f) 1.12f else 1f).setDuration(110).start()
                v.invalidate()
            }
        }
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            p.style = Paint.Style.FILL
            p.color = if (isFocused) accentOf() else 0x40FFFFFF
            cv.drawRoundRect(0f, 0f, w, h, w * 0.32f, w * 0.32f, p)
            p.color = if (isFocused) onAccent(accentOf()) else Color.WHITE
            val cx = w / 2
            val cy = h / 2
            if (kind == 0) {
                p.style = Paint.Style.STROKE
                p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = w * 0.10f
                cv.drawCircle(cx, cy, w * 0.20f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cs = Math.cos(a).toFloat()
                    val sn = Math.sin(a).toFloat()
                    cv.drawLine(cx + cs * w * 0.30f, cy + sn * w * 0.30f, cx + cs * w * 0.38f, cy + sn * w * 0.38f, p)
                }
            } else {
                val s = w * 0.15f
                val g = w * 0.07f
                val x0 = cx - (1.5f * s + g)
                val y0 = cy - (1.5f * s + g)
                for (ri in 0..2) {
                    for (ci in 0..2) {
                        val x = x0 + ci * (s + g)
                        val y = y0 + ri * (s + g)
                        cv.drawRoundRect(x, y, x + s, y + s, s / 3, s / 3, p)
                    }
                }
            }
        }
    }

    /** Кнопка VPN: белый ключ = включён, светло-серый перечёркнутый ключ = выключен */
    private class VpnBtn(c: Context, private val accentOf: () -> Int, private val isOn: () -> Boolean) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        init {
            isFocusable = true; isClickable = true
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.12f else 1f).scaleY(if (f) 1.12f else 1f).setDuration(110).start()
                v.invalidate()
            }
        }
        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val on = isOn()
            p.style = Paint.Style.FILL
            p.color = if (isFocused) accentOf() else 0x40FFFFFF
            cv.drawRoundRect(0f, 0f, w, h, w * 0.32f, w * 0.32f, p)
            p.color = if (isFocused) onAccent(accentOf()) else if (on) Color.WHITE else 0xFFC3CAD3.toInt()
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = w * 0.075f
            val cx = w / 2
            val cy = h / 2
            cv.save()
            cv.rotate(-45f, cx, cy)
            cv.drawCircle(cx - w * 0.20f, cy, w * 0.11f, p)
            cv.drawLine(cx - w * 0.09f, cy, cx + w * 0.26f, cy, p)
            cv.drawLine(cx + w * 0.16f, cy, cx + w * 0.16f, cy + w * 0.11f, p)
            cv.drawLine(cx + w * 0.26f, cy, cx + w * 0.26f, cy + w * 0.11f, p)
            cv.restore()
            if (!on) cv.drawLine(w * 0.22f, h * 0.22f, w * 0.78f, h * 0.78f, p)
        }
    }

    private val themes = listOf(
        Theme("Полночь", intArrayOf(col("#070B16"), col("#0F1B33"), col("#1B3358")), col("#5AA9FF")),
        Theme("Океан", intArrayOf(col("#031A27"), col("#0A3B4A"), col("#12636E")), col("#3DD9E8")),
        Theme("Закат", intArrayOf(col("#1A0A24"), col("#4A1740"), col("#8A3A3A")), col("#FF9E57")),
        Theme("Лес", intArrayOf(col("#07140D"), col("#12301D"), col("#245A33")), col("#A5E36B")),
        Theme("Графит", intArrayOf(col("#0C0D0F"), col("#17191D"), col("#25282E")), col("#B8C4CE")),
        Theme("Неон", intArrayOf(col("#07000F"), col("#1D0A38"), col("#002B45")), col("#00E5FF")),
        Theme("Сакура", intArrayOf(col("#1C0B16"), col("#44213A"), col("#7A3B5C")), col("#FF8FB8")),
        Theme("Пустыня", intArrayOf(col("#1B1109"), col("#43301B"), col("#7A5A30")), col("#FFC857")),
        Theme("Индиго", intArrayOf(col("#0A0A24"), col("#1A1A4D"), col("#2B2B7A")), col("#9FA8FF")),
        Theme("Рубин", intArrayOf(col("#1A0508"), col("#4A0F1A"), col("#7C1D2E")), col("#FF6B7D")),
        Theme("Изумруд", intArrayOf(col("#03160F"), col("#06402F"), col("#0B6B4F")), col("#34E0A1")),
        Theme("Чёрный", intArrayOf(col("#000000"), col("#050505"), col("#0D0D0D")), col("#FFFFFF"))
    )

    private val io = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val iconCache = ConcurrentHashMap<String, IconData>()
    private val favTiles = HashMap<String, View>()
    private var apps: List<App> = emptyList()
    private var byPkg: Map<String, App> = emptyMap()
    private var appsLoaded = false
    private var homeEmpty = true
    private var dirty = true
    private var accent = 0
    private var layer = 0 // 0 главный, 1 все приложения, 2 настройки, 3 подраздел
    private var backTarget: () -> Unit = {}
    private var movePkg: String? = null
    private var lastPkg: String? = null      // последняя выбранная плитка на главном экране
    private var lastAppsPkg: String? = null  // последний выбранный пункт в меню всех приложений
    private var netCb: ConnectivityManager.NetworkCallback? = null

    // размеры плиток меню «Все приложения» (считаются при открытии)
    private var aW = 0
    private var aH = 0
    private var aRad = 0f
    private var aSq = false

    private lateinit var wall: ImageView
    private lateinit var scrim: View
    private lateinit var mainCol: LinearLayout
    private lateinit var homeBox: LinearLayout
    private lateinit var favGrid: LinearLayout
    private lateinit var appsIcon: IconBtn
    private lateinit var gearV: IconBtn
    private lateinit var vpnBtn: VpnBtn
    private lateinit var appsCard: LinearLayout
    private var vpnOn = false
    private lateinit var appsLayer: FrameLayout
    private lateinit var grid: GridView
    private lateinit var appsAdapter: AppsAdapter
    private lateinit var settingsLayer: FrameLayout
    private lateinit var panel: LinearLayout
    private var clockV: TextView? = null
    private var dateV: TextView? = null

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { dirty = true }
    }

    // ================= жизненный цикл =================
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        accent = prefs.getInt("accent", themes[0].accent)
        lastPkg = prefs.getString("lastPkg", null)
        buildUi()
        applyWallpaper(); applyDim(); applyFavBg(); applyClock(); applyBtnSize(); applyAlign(); applyAppsBg()
        registerNet()
        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addDataScheme("package")
        })
    }

    override fun onResume() {
        super.onResume()
        if (dirty) { dirty = false; loadApps() }
        updateVpn()
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putString("lastPkg", lastPkg).apply()
        if (movePkg != null) { movePkg = null; renderFavs() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (movePkg != null) { movePkg = null; renderFavs() }
        closeLayers() // Home: возвращаемся на главный экран и на последнюю выбранную плитку
    }

    override fun onDestroy() {
        try {
            netCb?.let { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        } catch (e: Exception) { }
        unregisterReceiver(pkgReceiver)
        super.onDestroy()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (movePkg != null) {
            var dr = 0
            var dc = 0
            when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> dc = -1
                KeyEvent.KEYCODE_DPAD_RIGHT -> dc = 1
                KeyEvent.KEYCODE_DPAD_UP -> dr = -1
                KeyEvent.KEYCODE_DPAD_DOWN -> dr = 1
            }
            val dir = dr != 0 || dc != 0
            val end = e.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || e.keyCode == KeyEvent.KEYCODE_ENTER ||
                e.keyCode == KeyEvent.KEYCODE_BACK
            if (dir || end) {
                if (e.action == KeyEvent.ACTION_DOWN) {
                    if (dir) moveStep(dr, dc) else if (e.repeatCount == 0) endMove()
                }
                return true
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_MENU || k == KeyEvent.KEYCODE_SETTINGS) { showSettings(); return true }
        return super.onKeyDown(k, e)
    }

    override fun onBackPressed() {
        when (layer) {
            1, 2 -> closeLayers()
            3 -> backTarget()
            else -> {}
        }
    }

    // ================= каркас интерфейса =================
    private fun buildUi() {
        val root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, FrameLayout.LayoutParams(-1, -1))
        scrim = View(this)
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        mainCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(40), dp(56), dp(32))
            clipChildren = false; clipToPadding = false
        }

        // строка состояния: часы + VPN слева, кнопки справа
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val widgets = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clockV = Widgets.map["clock"]?.create(this, JSONObject().put("size", 72)) as? TextView
        dateV = Widgets.map["date"]?.create(this, JSONObject().put("size", 22)) as? TextView
        vpnBtn = VpnBtn(this, { accent }, { vpnOn })
        vpnBtn.setOnClickListener { onVpnClick() }
        val clockRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        clockV?.let { shadow(it); clockRow.addView(it) }
        clockRow.addView(vpnBtn, LinearLayout.LayoutParams(dp(56), dp(56)).apply { leftMargin = dp(18) })
        widgets.addView(clockRow)
        dateV?.let { shadow(it); widgets.addView(it) }
        top.addView(widgets, LinearLayout.LayoutParams(0, -2, 1f))
        appsIcon = IconBtn(this, 1) { accent }
        appsIcon.setOnClickListener { showApps() }
        top.addView(appsIcon, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14); topMargin = dp(8) })
        gearV = IconBtn(this, 0) { accent }
        gearV.setOnClickListener { showSettings() }
        top.addView(gearV, LinearLayout.LayoutParams(dp(56), dp(56)).apply { topMargin = dp(8) })
        mainCol.addView(top, LinearLayout.LayoutParams(-1, -2))

        // главный экран: панель с плитками внизу, ширина по содержимому
        favGrid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false; clipToPadding = false
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        homeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            clipChildren = false; clipToPadding = false
            setPadding(0, 0, 0, dp(36))
            addView(favGrid, LinearLayout.LayoutParams(-2, -2))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true; isVerticalScrollBarEnabled = false
            clipChildren = false; clipToPadding = false
            addView(homeBox, ViewGroup.LayoutParams(-1, -1))
        }
        mainCol.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(mainCol, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Все приложения» (всплывающее окно) ---
        appsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0x66000000) }
        appsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(12))
        }
        appsCard.addView(TextView(this).apply {
            text = "Все приложения"; textSize = 24f; setTextColor(Color.WHITE); setPadding(dp(8), 0, 0, dp(10))
        })
        appsAdapter = AppsAdapter()
        grid = GridView(this).apply {
            adapter = appsAdapter
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(6); horizontalSpacing = dp(6)
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isVerticalScrollBarEnabled = false
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos], false) }
            setOnItemLongClickListener { _, _, pos, _ -> appMenu(apps[pos]); true }
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    lastAppsPkg = apps.getOrNull(position)?.pkg
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        appsCard.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        appsLayer.addView(appsCard, FrameLayout.LayoutParams(-2, -2))
        root.addView(appsLayer, FrameLayout.LayoutParams(-1, -1))

        // --- слой «Настройки» (справа, слева виден предпросмотр) ---
        settingsLayer = FrameLayout(this).apply { visibility = View.GONE; setBackgroundColor(0x55000000) }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(24))
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(col("#171D29")) }
        }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(panel) }
        settingsLayer.addView(sv, FrameLayout.LayoutParams(dp(520), -2, Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(40); topMargin = dp(24); bottomMargin = dp(24)
        })
        root.addView(settingsLayer, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        appsIcon.requestFocus()
    }

    private fun shadow(t: TextView) = t.setShadowLayer(5f, 0f, 2f, 0xCC000000.toInt())

    private fun fadeIn(v: View) {
        if (v.visibility != View.VISIBLE) {
            v.alpha = 0f; v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(170).start()
        }
    }

    private fun closeLayers() {
        layer = 0
        appsLayer.visibility = View.GONE
        settingsLayer.visibility = View.GONE
        mainCol.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        defaultFocus()
    }

    /** Фокус: последняя выбранная плитка, иначе первая по порядку, иначе кнопка меню */
    private fun defaultFocus() {
        val last = favTiles[lastPkg]
        if (last != null) { last.requestFocus(); return }
        val first = layoutSlots().sortedWith(compareBy<Slot>({ it.r }, { it.c })).firstOrNull()
        (first?.let { favTiles[it.pkg] } ?: appsIcon).requestFocus()
    }

    // ================= применение настроек =================
    private fun applyDim() {
        val d = prefs.getInt("dim", 40) * 255 / 100
        scrim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(alpha(Color.BLACK, (d + 30).coerceAtMost(255)), alpha(Color.BLACK, d), alpha(Color.BLACK, (d + 50).coerceAtMost(255)))
        )
    }

    private fun applyFavBg() {
        if (homeEmpty) { favGrid.background = null; return }
        val a = prefs.getInt("favOp", 35) * 255 / 100
        favGrid.background = GradientDrawable().apply {
            cornerRadius = dp(26).toFloat()
            setColor(alpha(prefs.getInt("favBg", Color.BLACK), a))
        }
    }

    private fun applyAppsBg() {
        appsCard.background = GradientDrawable().apply {
            cornerRadius = dp(28).toFloat()
            setColor(alpha(prefs.getInt("aBg", col("#0B0F16")), prefs.getInt("aOp", 93) * 255 / 100))
        }
    }

    private fun applyAlign() {
        val h = when (prefs.getInt("hAlign", 1)) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        homeBox.gravity = Gravity.BOTTOM or h
    }

    private fun applyClock() {
        val k = prefs.getInt("clkPct", 100) / 100f
        val sec = prefs.getInt("clkSec", 0) == 1
        val h24 = prefs.getInt("clk24", 1) == 1
        val f = if (h24) (if (sec) "HH:mm:ss" else "HH:mm") else (if (sec) "h:mm:ss a" else "h:mm a")
        (clockV as? TextClock)?.let { it.format24Hour = f; it.format12Hour = f }
        clockV?.textSize = 72f * k
        dateV?.textSize = 22f * k
        clockV?.visibility = if (prefs.getInt("clkShow", 1) == 1) View.VISIBLE else View.GONE
        dateV?.visibility = if (prefs.getInt("dateShow", 1) == 1) View.VISIBLE else View.GONE
    }

    private fun applyBtnSize() {
        val s = dp(prefs.getInt("btnDp", 56))
        for (v in listOf<View>(vpnBtn, appsIcon, gearV)) {
            val lp = v.layoutParams as LinearLayout.LayoutParams
            lp.width = s; lp.height = s
            v.layoutParams = lp
        }
    }

    // ================= VPN =================
    private fun registerNet() {
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: Network) { ui.post { updateVpn() } }
                override fun onLost(n: Network) { ui.post { updateVpn() } }
            }
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                .build()
            cm.registerNetworkCallback(req, cb)
            netCb = cb
        } catch (e: Exception) { }
    }

    private fun vpnActive(): Boolean = try {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.allNetworks.any { n -> cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
    } catch (e: Exception) { false }

    private fun updateVpn() {
        val mode = prefs.getInt("vpnShow", 1) // 0 скрыть, 1 всегда, 2 только когда включён
        vpnOn = vpnActive()
        vpnBtn.visibility = if (mode == 0 || (mode == 2 && !vpnOn)) View.GONE else View.VISIBLE
        vpnBtn.invalidate()
    }

    /** Нажатие на кнопку VPN: открыть настройки VPN, запустить выбранное приложение или отправить своё действие */
    private fun onVpnClick() {
        val on = vpnActive()
        try {
            when (prefs.getInt("vpnAct", 0)) {
                0 -> openVpnSettings()
                1 -> {
                    val a = byPkg[prefs.getString("vpnPkg", "") ?: ""]
                    if (a == null) toast("Выберите приложение VPN в настройках строки состояния") else startApp(a)
                }
                else -> sendVpnIntent(on)
            }
        } catch (e: Exception) { toast("Не удалось выполнить действие") }
        ui.postDelayed({ updateVpn() }, 1500)
        ui.postDelayed({ updateVpn() }, 4000)
    }

    private fun openVpnSettings() {
        try {
            startActivity(Intent("android.settings.VPN_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("На этом ТВ нет экрана настроек VPN")
            openSystemSettings()
        }
    }

    private fun sendVpnIntent(on: Boolean) {
        val onAct = (prefs.getString("vpnOnAct", "") ?: "").trim()
        val offAct = (prefs.getString("vpnOffAct", "") ?: "").trim()
        val action = if (on && offAct.isNotEmpty()) offAct else onAct
        if (action.isEmpty()) { toast("Задайте действие в настройках кнопки VPN"); return }
        val i = Intent(action)
        val pkg = (prefs.getString("vpnIPkg", "") ?: "").trim()
        if (pkg.isNotEmpty()) i.setPackage(pkg)
        (prefs.getString("vpnIExtra", "") ?: "").split(";").forEach { kv ->
            val p = kv.split("=", limit = 2)
            if (p.size == 2 && p[0].isNotBlank()) i.putExtra(p[0].trim(), p[1].trim())
        }
        when (prefs.getInt("vpnType", 0)) {
            0 -> sendBroadcast(i)
            1 -> startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else -> {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            }
        }
    }

    // ================= приложения =================
    private fun loadApps() = io.execute {
        val pm = packageManager
        val out = LinkedHashMap<String, App>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                val p = ri.activityInfo.packageName
                if (p == packageName || out.containsKey(p)) continue
                out[p] = App(p, ri.loadLabel(pm).toString(), ri, cat)
            }
        }
        val list = out.values.sortedBy { it.label.lowercase() }
        ui.post {
            apps = list; byPkg = list.associateBy { it.pkg }; appsLoaded = true
            renderFavs(); appsAdapter.notifyDataSetChanged()
            if (layer == 0) defaultFocus()
        }
        list.forEach { if (!iconCache.containsKey(it.pkg)) iconCache[it.pkg] = loadIconData(it) }
    }

    /**
     * Запуск как из обычного лаунчера (ACTION_MAIN + категория + NEW_TASK + RESET_TASK_IF_NEEDED):
     * если приложение уже есть в недавних, Android вернёт его задачу на экран, а не запустит заново.
     */
    private fun startApp(a: App) {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(a.cat)
                .setComponent(ComponentName(a.pkg, a.ri.activityInfo.name))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        )
    }

    private fun launch(a: App, fromHome: Boolean) {
        if (fromHome) lastPkg = a.pkg else lastAppsPkg = a.pkg
        prefs.edit().putString("lastPkg", lastPkg).apply()
        try { startApp(a) } catch (e: Exception) { toast("Не удалось запустить") }
    }

    private fun appMenu(a: App) {
        val onHome = rawSlots().any { it.pkg == a.pkg }
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (onHome) {
            items.add("Переместить на главном экране"); acts.add { startMove(a.pkg) }
            items.add("Убрать с главного экрана"); acts.add { removeFromHome(a.pkg) }
        } else {
            items.add("Добавить на главный экран"); acts.add { addToHome(a.pkg) }
        }
        items.add("О приложении")
        acts.add { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        items.add("Удалить")
        acts.add { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        AlertDialog.Builder(this).setTitle(a.label).setItems(items.toTypedArray()) { _, w -> acts[w]() }.show()
    }

    // ================= плитки (как в Google TV) =================
    private fun loadIconData(a: App): IconData {
        val pm = packageManager
        val banner: Drawable? = try {
            a.ri.activityInfo.loadBanner(pm) ?: a.ri.activityInfo.applicationInfo.loadBanner(pm)
        } catch (e: Exception) { null }
        val icon = a.ri.loadIcon(pm)
        return IconData(banner, icon, avgColor(icon))
    }

    /** Средний цвет значка (для плитки у приложений без баннера), слегка затемнённый */
    private fun avgColor(d: Drawable): Int {
        return try {
            val n = 16
            val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            d.setBounds(0, 0, n, n); d.draw(cv)
            var r = 0L; var g = 0L; var b = 0L; var cnt = 0L
            for (y in 0 until n) for (x in 0 until n) {
                val px = bmp.getPixel(x, y)
                if (Color.alpha(px) > 128) { r += Color.red(px); g += Color.green(px); b += Color.blue(px); cnt++ }
            }
            bmp.recycle()
            if (cnt == 0L) col("#2A2F3A")
            else Color.rgb((r / cnt * 0.55).toInt(), (g / cnt * 0.55).toInt(), (b / cnt * 0.55).toInt())
        } catch (e: Exception) { col("#2A2F3A") }
    }

    private fun tileImage(r: Float): ImageView = ImageView(this).apply {
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
        }
        background = GradientDrawable().apply { cornerRadius = r; setColor(0x1AFFFFFF) }
    }

    private fun showIcon(iv: ImageView, d: IconData, h: Int, r: Float, square: Boolean) {
        val useBanner = !square && d.banner != null
        val dr: Drawable = if (useBanner) d.banner!! else d.icon
        iv.setImageDrawable(dr.constantState?.newDrawable() ?: dr)
        if (useBanner) {
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setPadding(0, 0, 0, 0); iv.background = null
        } else if (square) {
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(0, 0, 0, 0); iv.background = null
        } else {
            // у приложения нет баннера: значок по центру на плитке его среднего цвета
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            val p = (h * 0.16f).toInt()
            iv.setPadding(p, p, p, p)
            iv.background = GradientDrawable().apply { cornerRadius = r; setColor(d.bg) }
        }
    }

    private fun bindIcon(a: App, iv: ImageView, h: Int, r: Float, square: Boolean) {
        iv.tag = a.pkg
        val c = iconCache[a.pkg]
        if (c != null) { showIcon(iv, c, h, r, square); return }
        iv.setImageDrawable(null)
        iv.setPadding(0, 0, 0, 0)
        iv.background = GradientDrawable().apply { cornerRadius = r; setColor(0x1AFFFFFF) }
        io.execute {
            val d = loadIconData(a)
            iconCache[a.pkg] = d
            ui.post { if (iv.tag == a.pkg) showIcon(iv, d, h, r, square) }
        }
    }

    private fun labelView(text: String, key: String) = TextView(this).apply {
        this.text = text; textSize = 13f * prefs.getInt(key, 100) / 100f; setTextColor(Color.WHITE)
        maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        setShadowLayer(4f, 0f, 2f, 0xCC000000.toInt())
    }

    // ================= главный экран: ячейки =================
    private fun rawSlots(): MutableList<Slot> =
        (prefs.getString("slots", "") ?: "").split(";").mapNotNull { s ->
            val p = s.split(",")
            val r = if (p.size == 3) p[1].toIntOrNull() else null
            val c = if (p.size == 3) p[2].toIntOrNull() else null
            if (r != null && c != null && p[0].isNotEmpty()) Slot(p[0], r, c) else null
        }.toMutableList()

    private fun saveSlots(l: List<Slot>) {
        prefs.edit().putString("slots", l.joinToString(";") { it.pkg + "," + it.r + "," + it.c }).apply()
    }

    /** Реальная раскладка: установленные приложения; вышедшие за сетку или столкнувшиеся ставятся в свободные ячейки */
    private fun layoutSlots(): List<Slot> {
        val rows = prefs.getInt("hRows", 2)
        val cols = prefs.getInt("hCols", 6)
        val taken = HashSet<Int>()
        val out = ArrayList<Slot>()
        val pending = ArrayList<Slot>()
        for (s in rawSlots()) {
            if (!byPkg.containsKey(s.pkg)) continue
            if (s.r in 0 until rows && s.c in 0 until cols && taken.add(s.r * cols + s.c)) out.add(s) else pending.add(s)
        }
        for (s in pending) {
            loop@ for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (taken.add(r * cols + c)) { out.add(Slot(s.pkg, r, c)); break@loop }
                }
            }
        }
        return out
    }

    private fun persist(vis: List<Slot>, drop: String?) {
        val keep = rawSlots().filter { s -> s.pkg != drop && vis.none { it.pkg == s.pkg } }
        saveSlots(vis + keep)
    }

    private fun addToHome(pkg: String) {
        val vis = layoutSlots().toMutableList()
        val rows = prefs.getInt("hRows", 2)
        val cols = prefs.getInt("hCols", 6)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (vis.none { it.r == r && it.c == c }) {
                    vis.add(Slot(pkg, r, c))
                    persist(vis, null); renderFavs()
                    toast("Добавлено на главный экран")
                    return
                }
            }
        }
        toast("На главном экране нет места — увеличьте сетку в настройках")
    }

    private fun removeFromHome(pkg: String) {
        persist(layoutSlots().filter { it.pkg != pkg }, pkg)
        renderFavs()
    }

    private fun renderFavs() {
        if (!appsLoaded) return
        favGrid.removeAllViews(); favTiles.clear()
        val rows = prefs.getInt("hRows", 2)
        val cols = prefs.getInt("hCols", 6)
        val slots = layoutSlots()
        val moving = movePkg != null
        homeEmpty = slots.isEmpty() && !moving
        applyFavBg()
        if (homeEmpty) {
            favGrid.addView(TextView(this).apply {
                text = "Главный экран пуст. Откройте «Все приложения» (значок сетки справа вверху), зажмите OK на приложении и выберите «Добавить на главный экран»."
                textSize = 15f; setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 2f, 0xCC000000.toInt())
                setPadding(dp(8), dp(8), dp(8), dp(8))
                maxWidth = resources.displayMetrics.widthPixels / 2
            })
            return
        }
        // при перемещении показываем всю сетку, иначе только занятую область (панель сужается/расширяется)
        val r0 = if (moving) 0 else slots.minOf { it.r }
        val r1 = if (moving) rows - 1 else slots.maxOf { it.r }
        val c0 = if (moving) 0 else slots.minOf { it.c }
        val c1 = if (moving) cols - 1 else slots.maxOf { it.c }
        val square = prefs.getInt("hFmt", 0) == 1
        val showLbl = prefs.getInt("hLbl", 1) == 1
        val avail = resources.displayMetrics.widthPixels - dp(112) - dp(28)
        val w = minOf(dp(prefs.getInt("hTile", 150)), avail / (c1 - c0 + 1) - dp(24)).coerceAtLeast(dp(40))
        val h = if (square) w else w * 9 / 16
        val rad = h * prefs.getInt("hRad", 14) / 100f
        val byCell = slots.associateBy { it.r * 1000 + it.c }
        for (r in r0..r1) {
            val row = LinearLayout(this).apply { clipChildren = false; clipToPadding = false }
            for (c in c0..c1) {
                val s = byCell[r * 1000 + c]
                val cell = if (s != null) favTile(byPkg[s.pkg]!!, w, h, rad, showLbl, square)
                else emptyCell(w, h, rad, showLbl, moving)
                row.addView(cell, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(4); rightMargin = dp(4) })
            }
            favGrid.addView(row, LinearLayout.LayoutParams(-2, -2))
        }
    }

    private fun tileBg(pkg: String, f: Boolean): Drawable? {
        val r = dp(18).toFloat()
        if (pkg == movePkg) return GradientDrawable().apply { cornerRadius = r; setColor(alpha(accent, 0x66)); setStroke(dp(3), Color.WHITE) }
        if (f) return GradientDrawable().apply { cornerRadius = r; setColor(0x26FFFFFF); setStroke(dp(3), accent) }
        return null
    }

    private fun favTile(a: App, w: Int, h: Int, r: Float, lbl: Boolean, sq: Boolean): View {
        val iv = tileImage(r)
        bindIcon(a, iv, h, r, sq)
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true; isClickable = true
            tag = a.pkg
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(iv, LinearLayout.LayoutParams(w, h))
            if (lbl) addView(labelView(a.label, "hTxt"), LinearLayout.LayoutParams(w, -2).apply { topMargin = dp(6) })
            setOnFocusChangeListener { v, f ->
                v.animate().scaleX(if (f) 1.08f else 1f).scaleY(if (f) 1.08f else 1f).setDuration(110).start()
                v.background = tileBg(a.pkg, f)
                if (f) lastPkg = a.pkg
            }
            setOnClickListener { launch(a, true) }
            setOnLongClickListener { appMenu(a); true }
        }
        t.background = tileBg(a.pkg, false)
        favTiles[a.pkg] = t
        return t
    }

    private fun emptyCell(w: Int, h: Int, r: Float, lbl: Boolean, visible: Boolean): View {
        val iv = ImageView(this)
        if (visible) iv.background = GradientDrawable().apply {
            cornerRadius = r; setColor(0x22FFFFFF); setStroke(dp(2), 0x44FFFFFF)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(iv, LinearLayout.LayoutParams(w, h))
            if (lbl) addView(labelView(" ", "hTxt"), LinearLayout.LayoutParams(w, -2).apply { topMargin = dp(6) })
            visibility = if (visible) View.VISIBLE else View.INVISIBLE
        }
    }

    // ----- свободное перемещение по сетке -----
    private fun startMove(pkg: String) {
        closeLayers()
        if (layoutSlots().none { it.pkg == pkg }) { toast("Приложения нет на главном экране"); return }
        movePkg = pkg
        renderFavs()
        favTiles[pkg]?.requestFocus()
        toast("Стрелки — переместить в любую ячейку, OK — готово")
    }

    private fun moveStep(dr: Int, dc: Int) {
        val p = movePkg ?: return
        val vis = layoutSlots().toMutableList()
        val s = vis.firstOrNull { it.pkg == p } ?: return
        val nr = s.r + dr
        val nc = s.c + dc
        if (nr < 0 || nr >= prefs.getInt("hRows", 2) || nc < 0 || nc >= prefs.getInt("hCols", 6)) return
        val other = vis.firstOrNull { it.r == nr && it.c == nc }
        if (other != null) { other.r = s.r; other.c = s.c }
        s.r = nr; s.c = nc
        persist(vis, null)
        renderFavs()
        favTiles[p]?.requestFocus()
    }

    private fun endMove() {
        val p = movePkg
        movePkg = null
        renderFavs()
        if (p != null) favTiles[p]?.requestFocus()
    }

    private fun reorderFromSettings() {
        val first = layoutSlots().sortedWith(compareBy<Slot>({ it.r }, { it.c })).firstOrNull()
        if (first == null) { toast("Главный экран пуст"); return }
        startMove(first.pkg)
    }

    // ================= меню «Все приложения» =================
    private fun showApps() {
        layer = 1
        settingsLayer.visibility = View.GONE
        fadeIn(appsLayer)
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        applyAppsBg()
        val dm = resources.displayMetrics
        val cw = dm.widthPixels * prefs.getInt("aWin", 80) / 100
        val ch = dm.heightPixels * prefs.getInt("aWinH", 80) / 100
        val gx = when (prefs.getInt("aPos", 1)) {
            0 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.CENTER_HORIZONTAL
        }
        appsCard.layoutParams = FrameLayout.LayoutParams(cw, ch, gx or Gravity.CENTER_VERTICAL).apply {
            leftMargin = dp(32); rightMargin = dp(32)
        }
        val cols = prefs.getInt("aCols", 6).coerceAtLeast(1)
        val avail = cw - dp(48) - dp(16)
        aSq = prefs.getInt("aFmt", 0) == 1
        aW = minOf(dp(prefs.getInt("aTile", 140)), avail / cols - dp(20)).coerceAtLeast(dp(40))
        aH = if (aSq) aW else aW * 9 / 16
        aRad = aH * prefs.getInt("aRad", 14) / 100f
        grid.numColumns = cols
        grid.selector = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(0x26FFFFFF); setStroke(dp(3), accent) }
        grid.adapter = appsAdapter
        val i = apps.indexOfFirst { it.pkg == lastAppsPkg }
        if (i >= 0) grid.setSelection(i)
        grid.requestFocus()
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int): Any = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val a = apps[p]
            val v = (cv ?: cell()) as LinearLayout
            (v.getChildAt(1) as TextView).text = a.label
            bindIcon(a, v.getChildAt(0) as ImageView, aH, aRad, aSq)
            return v
        }
    }

    private fun cell(): LinearLayout {
        val iv = tileImage(aRad)
        val tv = labelView("", "aTxt")
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(8), dp(6), dp(6))
            addView(iv, LinearLayout.LayoutParams(aW, aH))
            addView(tv, LinearLayout.LayoutParams(aW, -2).apply { topMargin = dp(6) })
        }
    }

    // ================= настройки: каркас страниц =================
    private fun openPage(back: (() -> Unit)?) {
        layer = if (back == null) 2 else 3
        val closer: () -> Unit = { closeLayers() }
        backTarget = back ?: closer
        appsLayer.visibility = View.GONE
        fadeIn(settingsLayer)
        mainCol.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        panel.removeAllViews()
    }

    // ----- главное меню -----
    private fun showSettings() {
        openPage(null)
        panelTitle("Настройки J.Launcher")
        section("ЭКРАНЫ")
        menuRow("Главный экран", "›") { showHome() }
        menuRow("Строка состояния", "›") { showStatus() }
        menuRow("Меню всех приложений", "›") { showAppsMenu() }
        section("СИСТЕМА")
        menuRow("Настройки Android", "›") { openSystemSettings() }
        menuRow("Сбросить всё", null) { resetAll() }
        menuRow("Закрыть", null) { closeLayers() }
        panel.requestFocus()
    }

    // ----- главный экран: хаб -----
    private fun showHome() {
        openPage { showSettings() }
        panelTitle("Главный экран")
        section("РАСКЛАДКА")
        menuRow("Сетка и положение", "›") { showHomeGrid() }
        menuRow("Плитки приложений", "›") { showHomeTiles() }
        menuRow("Расставить приложения", "›") { reorderFromSettings() }
        section("ОФОРМЛЕНИЕ")
        menuRow("Тема и обои", "›") { showThemeWall() }
        menuRow("Цвета и фон панели", "›") { showColors() }
        menuRow("Назад", null) { showSettings() }
        panel.requestFocus()
    }

    private fun showHomeGrid() {
        openPage { showHome() }
        panelTitle("Сетка и положение")
        choice("Расположение значков", arrayOf("Слева", "По центру", "Справа"), "hAlign", 1) { applyAlign() }
        prefSlider("Строки", "hRows", 2, 1, 6, 1, "") { renderFavs() }
        prefSlider("Столбцы", "hCols", 6, 1, 12, 1, "") { renderFavs() }
        menuRow("Расставить приложения", "›") { reorderFromSettings() }
        menuRow("Назад", null) { showHome() }
        panel.requestFocus()
    }

    private fun showHomeTiles() {
        openPage { showHome() }
        panelTitle("Плитки приложений")
        choice("Формат", arrayOf("Плитки 16:9", "Квадрат"), "hFmt", 0) { renderFavs() }
        prefSlider("Размер плиток", "hTile", 150, 80, 300, 10, " dp") { renderFavs() }
        prefSlider("Размер текста", "hTxt", 100, 60, 200, 10, "%") { renderFavs() }
        prefSlider("Скругление углов", "hRad", 14, 0, 50, 2, "%") { renderFavs() }
        choice("Подписи", arrayOf("Скрыть", "Показать"), "hLbl", 1) { renderFavs() }
        menuRow("Назад", null) { showHome() }
        panel.requestFocus()
    }

    private fun showThemeWall() {
        openPage { showHome() }
        panelTitle("Тема и обои")
        section("ГОТОВЫЕ ТЕМЫ (ФОН + АКЦЕНТ)")
        val cards = themes.map { themeCard(it) }
        addSwatches(cards, 4, dp(104), dp(70))
        section("ОБОИ")
        slider("Затемнение обоев", 0, 80, prefs.getInt("dim", 40), 5, { "$it%" }) { p ->
            prefs.edit().putInt("dim", p).apply(); applyDim()
        }
        menuRow("Своя картинка из файла", null) { pickImage() }
        menuRow("Картинка по ссылке", null) { askUrl() }
        menuRow("Назад", null) { showHome() }
        cards[0].requestFocus()
    }

    private fun showColors() {
        openPage { showHome() }
        panelTitle("Цвета и фон панели")
        section("ЦВЕТ АКЦЕНТА (ВЕСЬ ИНТЕРФЕЙС)")
        val accents = listOf("#3D8BFF", "#00BCD4", "#1DE9B6", "#4CAF50", "#C6FF00", "#FFD600",
            "#FF9100", "#FF5252", "#FF4081", "#E040FB", "#7C4DFF", "#FFFFFF").map { col(it) }
        val views = accents.map { c -> swatch(intArrayOf(c)) { setAccent(c) } }
        addSwatches(views, 6, dp(64), dp(44))
        val hsv = FloatArray(3)
        Color.colorToHSV(accent, hsv)
        slider("Свой оттенок", 0, 360, hsv[0].toInt(), 8, { "$it°" }) { p ->
            setAccent(Color.HSVToColor(floatArrayOf(p.toFloat(), 0.75f, 1f)))
        }
        section("ФОН ПАНЕЛИ С ПРИЛОЖЕНИЯМИ")
        val bgs = listOf("#000000", "#10141C", "#1B2230", "#FFFFFF", "#3D8BFF",
            "#7C4DFF", "#FF5252", "#4CAF50", "#FFD600", "#FF9100").map { col(it) }
        val bgViews = bgs.map { c -> swatch(intArrayOf(c)) { prefs.edit().putInt("favBg", c).apply(); applyFavBg() } }
        addSwatches(bgViews, 5, dp(80), dp(44))
        slider("Прозрачность панели", 0, 100, 100 - prefs.getInt("favOp", 35), 5, { "$it%" }) { p ->
            prefs.edit().putInt("favOp", 100 - p).apply(); applyFavBg()
        }
        menuRow("Назад", null) { showHome() }
        views[0].requestFocus()
    }

    // ----- строка состояния -----
    private fun showStatus() {
        openPage { showSettings() }
        panelTitle("Строка состояния")
        section("ЧАСЫ")
        choice("Часы", arrayOf("Скрыть", "Показать"), "clkShow", 1) { applyClock() }
        choice("Дата", arrayOf("Скрыть", "Показать"), "dateShow", 1) { applyClock() }
        choice("Формат времени", arrayOf("12 часов", "24 часа"), "clk24", 1) { applyClock() }
        choice("Секунды", arrayOf("Нет", "Да"), "clkSec", 0) { applyClock() }
        prefSlider("Размер часов и даты", "clkPct", 100, 60, 250, 10, "%") { applyClock() }
        section("КНОПКА VPN РЯДОМ С ЧАСАМИ")
        choice("Показ кнопки", arrayOf("Скрыть", "Всегда", "Когда включён"), "vpnShow", 1) { updateVpn() }
        choice("Действие по нажатию", arrayOf("Настройки VPN", "Приложение", "Свой intent"), "vpnAct", 0) { }
        val appName = byPkg[prefs.getString("vpnPkg", "") ?: ""]?.label ?: "не выбрано"
        val appRow = menuRow("Приложение VPN", appName) { }
        appRow.setOnClickListener {
            val list = apps
            AlertDialog.Builder(this).setTitle("Приложение VPN")
                .setItems(list.map { it.label }.toTypedArray()) { _, w ->
                    prefs.edit().putString("vpnPkg", list[w].pkg).apply()
                    (appRow.tag as TextView).text = list[w].label
                }.show()
        }
        menuRow("Свой intent (включить / выключить)", "›") { showVpnIntent() }
        section("КНОПКИ")
        prefSlider("Размер кнопок (VPN, приложения, настройки)", "btnDp", 56, 40, 110, 4, " dp") { applyBtnSize() }
        menuRow("Назад", null) { showSettings() }
        panel.requestFocus()
    }

    private fun showVpnIntent() {
        openPage { showStatus() }
        panelTitle("Свой intent для VPN")
        panel.addView(label("Если VPN выключен, по нажатию отправляется действие «включить»; если включён — «выключить». Если «выключить» пусто, отправляется то же действие (переключатель)."))
        choice("Способ отправки", arrayOf("Broadcast", "Activity", "Service"), "vpnType", 0) { }
        editRow("Действие «включить»", "vpnOnAct", "com.example.action.ON", "не задано")
        editRow("Действие «выключить»", "vpnOffAct", "com.example.action.OFF", "как «включить»")
        editRow("Пакет приложения", "vpnIPkg", "com.example.vpn", "не задан")
        editRow("Параметры (ключ=значение;…)", "vpnIExtra", "tunnel=wg0", "нет")
        menuRow("Шаблон: WireGuard", "›") { wireguardPreset() }
        menuRow("Назад", null) { showStatus() }
        panel.requestFocus()
    }

    /** Строка с текстовым значением: по нажатию открывается ввод */
    private fun editRow(title: String, key: String, hint: String, empty: String) {
        val cur = { prefs.getString(key, "") ?: "" }
        val row = menuRow(title, cur().ifEmpty { empty }) { }
        row.setOnClickListener {
            val et = EditText(this).apply { setText(cur()); this.hint = hint; setSingleLine() }
            AlertDialog.Builder(this).setTitle(title).setView(et)
                .setPositiveButton("Сохранить") { _, _ ->
                    val t = et.text.toString().trim()
                    prefs.edit().putString(key, t).apply()
                    (row.tag as TextView).text = if (t.isEmpty()) empty else t
                }.setNegativeButton("Отмена", null).show()
        }
    }

    private fun wireguardPreset() {
        val et = EditText(this).apply { hint = "Имя туннеля (как в WireGuard)"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Шаблон WireGuard").setView(et)
            .setPositiveButton("Применить") { _, _ ->
                prefs.edit()
                    .putInt("vpnType", 0).putInt("vpnAct", 2)
                    .putString("vpnOnAct", "com.wireguard.android.action.SET_TUNNEL_UP")
                    .putString("vpnOffAct", "com.wireguard.android.action.SET_TUNNEL_DOWN")
                    .putString("vpnIPkg", "com.wireguard.android")
                    .putString("vpnIExtra", "tunnel=" + et.text.toString().trim())
                    .apply()
                if (Build.VERSION.SDK_INT >= 23) {
                    try { requestPermissions(arrayOf("com.wireguard.android.permission.CONTROL_TUNNELS"), 9) } catch (e: Exception) { }
                }
                toast("Шаблон применён. В WireGuard разрешите управление из других приложений")
                showVpnIntent()
            }.setNegativeButton("Отмена", null).show()
    }

    // ----- меню всех приложений -----
    private fun showAppsMenu() {
        openPage { showSettings() }
        panelTitle("Меню всех приложений")
        section("ОКНО")
        choice("Положение окна", arrayOf("Слева", "По центру", "Справа"), "aPos", 1) { }
        prefSlider("Ширина окна", "aWin", 80, 40, 100, 5, "%") { }
        prefSlider("Высота окна", "aWinH", 80, 40, 100, 5, "%") { }
        section("СЕТКА И ПЛИТКИ")
        choice("Формат", arrayOf("Плитки 16:9", "Квадрат"), "aFmt", 0) { }
        prefSlider("Столбцы", "aCols", 6, 3, 10, 1, "") { }
        prefSlider("Размер плиток", "aTile", 140, 80, 260, 10, " dp") { }
        prefSlider("Размер текста", "aTxt", 100, 60, 200, 10, "%") { }
        prefSlider("Скругление углов", "aRad", 14, 0, 50, 2, "%") { }
        section("ФОН ОКНА")
        val bgs = listOf("#0B0F16", "#000000", "#1B2230", "#2B1B3D", "#0B3B2E", "#3B0B1A", "#FFFFFF", "#3D8BFF", "#7C4DFF", "#FF9100").map { col(it) }
        val bgViews = bgs.map { c -> swatch(intArrayOf(c)) { prefs.edit().putInt("aBg", c).apply(); applyAppsBg() } }
        addSwatches(bgViews, 5, dp(80), dp(44))
        slider("Прозрачность фона", 0, 100, 100 - prefs.getInt("aOp", 93), 5, { "$it%" }) { p ->
            prefs.edit().putInt("aOp", 100 - p).apply(); applyAppsBg()
        }
        menuRow("Открыть меню приложений", "›") { showApps() }
        menuRow("Назад", null) { showSettings() }
        panel.requestFocus()
    }

    private fun openSystemSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Не удалось открыть настройки системы") }
    }

    private fun setAccent(c: Int) { accent = c; prefs.edit().putInt("accent", c).apply() }

    private fun applyThemePreset(t: Theme) {
        accent = t.accent
        prefs.edit().putInt("accent", t.accent).putString("wp_type", "grad").putString("wp_c", t.bg.joinToString(",")).apply()
        applyWallpaper()
        toast("Тема: " + t.name)
    }

    private fun resetAll() {
        prefs.edit().clear().apply()
        File(filesDir, "wallpaper.jpg").delete()
        movePkg = null; lastPkg = null; lastAppsPkg = null
        accent = themes[0].accent
        applyWallpaper(); applyDim(); applyClock(); applyBtnSize(); applyAlign(); applyAppsBg(); updateVpn()
        renderFavs(); showSettings()
        toast("Сброшено")
    }

    // ================= обои =================
    private fun applyWallpaper() {
        if (prefs.getString("wp_type", "grad") == "image") {
            val f = File(filesDir, "wallpaper.jpg")
            if (f.exists()) {
                io.execute {
                    val bmp = BitmapFactory.decodeFile(f.path)
                    if (bmp != null) ui.post { wall.background = null; wall.setImageBitmap(bmp) }
                }
                return
            }
        }
        val c = (prefs.getString("wp_c", null) ?: themes[0].bg.joinToString(","))
            .split(",").mapNotNull { it.trim().toIntOrNull() }
        val one = c.firstOrNull() ?: Color.BLACK
        val arr = if (c.size >= 2) c.toIntArray() else intArrayOf(one, one)
        wall.setImageDrawable(null)
        wall.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, arr)
    }

    private fun pickImage() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), 7)
        } catch (e: Exception) { toast("На этом ТВ нет выбора файлов — используйте ссылку") }
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        val u = d?.data ?: return
        if (rc == 7 && res == RESULT_OK) io.execute {
            try { contentResolver.openInputStream(u)!!.use { saveWallpaper(it.readBytes()) } }
            catch (e: Exception) { ui.post { toast("Не удалось загрузить картинку") } }
        }
    }

    private fun askUrl() {
        val et = EditText(this).apply { hint = "https://..."; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Ссылка на картинку").setView(et)
            .setPositiveButton("Загрузить") { _, _ ->
                val u = et.text.toString().trim()
                toast("Загрузка…")
                io.execute {
                    try {
                        val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 8000; c.readTimeout = 15000
                        saveWallpaper(c.inputStream.use { it.readBytes() })
                    } catch (e: Exception) { ui.post { toast("Не удалось загрузить") } }
                }
            }.setNegativeButton("Отмена", null).show()
    }

    private fun saveWallpaper(b: ByteArray) {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 1920) s *= 2
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
            ?: throw IllegalStateException("bad image")
        File(filesDir, "wallpaper.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        prefs.edit().putString("wp_type", "image").apply()
        ui.post { applyWallpaper(); toast("Обои установлены") }
    }

    // ================= элементы меню =================
    private fun panelTitle(t: String) {
        panel.addView(TextView(this).apply {
            text = t; textSize = 24f; setTextColor(Color.WHITE); setPadding(dp(4), 0, 0, dp(8))
        })
    }

    private fun section(t: String) {
        panel.addView(TextView(this).apply {
            text = t; textSize = 12f; letterSpacing = 0.12f; setTextColor(col("#7E8FA3"))
            setPadding(dp(6), dp(12), 0, dp(6))
        })
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 15f; setTextColor(col("#B8C7D9")); setPadding(dp(6), dp(6), 0, dp(2))
    }

    private fun rowBg(f: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(16).toFloat(); setColor(if (f) accent else 0x1AFFFFFF)
    }

    /** Строка меню: название слева, значение или › справа. Фокус = акцентная заливка с читаемым текстом */
    private fun menuRow(title: String, value: String?, onClick: () -> Unit): LinearLayout {
        val t = TextView(this).apply { text = title; textSize = 18f; setTextColor(Color.WHITE) }
        val v = TextView(this).apply {
            text = value ?: ""; textSize = 17f; setTextColor(col("#9FB0C3"))
            maxWidth = dp(200); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isFocusable = true; isClickable = true
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            addView(v, LinearLayout.LayoutParams(-2, -2))
        }
        row.tag = v
        row.background = rowBg(false)
        row.setOnFocusChangeListener { _, f ->
            row.background = rowBg(f)
            t.setTextColor(if (f) onAccent(accent) else Color.WHITE)
            v.setTextColor(if (f) onAccent(accent) else col("#9FB0C3"))
            row.animate().scaleX(if (f) 1.02f else 1f).scaleY(if (f) 1.02f else 1f).setDuration(110).start()
        }
        row.setOnClickListener { onClick() }
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        return row
    }

    /** Переключатель из нескольких вариантов в одну строку (выбранный подсвечен акцентом) */
    private fun choice(title: String, opts: Array<String>, key: String, def: Int, onChange: () -> Unit) {
        panel.addView(label(title))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btns = ArrayList<TextView>()
        fun repaint() {
            val cur = prefs.getInt(key, def)
            btns.forEachIndexed { i, b ->
                val sel = i == cur
                b.background = GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setColor(if (sel) accent else 0x1AFFFFFF)
                    setStroke(if (b.isFocused) dp(3) else 0, Color.WHITE)
                }
                b.setTextColor(if (sel) onAccent(accent) else Color.WHITE)
            }
        }
        opts.forEachIndexed { i, name ->
            val b = TextView(this).apply {
                text = name; textSize = 16f; gravity = Gravity.CENTER
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(6), dp(12), dp(6), dp(12))
                isFocusable = true; isClickable = true
                setOnFocusChangeListener { _, _ -> repaint() }
                setOnClickListener { prefs.edit().putInt(key, i).apply(); repaint(); onChange() }
            }
            btns.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        }
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        repaint()
    }

    /** Ползунок: влево/вправо на пульте меняют значение */
    private fun slider(title: String, lo: Int, hi: Int, value: Int, step: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): SeekBar {
        val tl = label(title + ": " + fmt(value))
        panel.addView(tl)
        val sb = SeekBar(this).apply {
            this.max = hi - lo
            keyProgressIncrement = step
            progress = value - lo
            progressTintList = ColorStateList.valueOf(accent)
            thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) { val v = p + lo; tl.text = title + ": " + fmt(v); onChange(v) }
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        panel.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2); bottomMargin = dp(10) })
        return sb
    }

    private fun prefSlider(title: String, key: String, def: Int, min: Int, max: Int, step: Int, suffix: String, onChange: () -> Unit) {
        slider(title, min, max, prefs.getInt(key, def).coerceIn(min, max), step, { it.toString() + suffix }) { v ->
            prefs.edit().putInt(key, v).apply(); onChange()
        }
    }

    private fun addSwatches(v: List<View>, per: Int, w: Int, h: Int) {
        v.chunked(per).forEach { chunk ->
            val r = LinearLayout(this)
            chunk.forEach { r.addView(it, LinearLayout.LayoutParams(w, h).apply { rightMargin = dp(8); bottomMargin = dp(8) }) }
            panel.addView(r)
        }
    }

    private fun swatch(colors: IntArray, onClick: () -> Unit): View {
        val v = View(this)
        val cs = if (colors.size == 1) intArrayOf(colors[0], colors[0]) else colors
        fun bg(f: Boolean) = GradientDrawable(GradientDrawable.Orientation.TL_BR, cs).apply {
            cornerRadius = dp(14).toFloat(); setStroke(if (f) dp(3) else 0, Color.WHITE)
        }
        v.background = bg(false)
        v.isFocusable = true; v.isClickable = true
        v.setOnFocusChangeListener { _, f ->
            v.background = bg(f)
            v.animate().scaleX(if (f) 1.08f else 1f).scaleY(if (f) 1.08f else 1f).setDuration(110).start()
        }
        v.setOnClickListener { onClick() }
        return v
    }

    private fun themeCard(t: Theme): View {
        val fl = FrameLayout(this)
        fun bg(f: Boolean) = GradientDrawable(GradientDrawable.Orientation.TL_BR, t.bg).apply {
            cornerRadius = dp(14).toFloat(); setStroke(if (f) dp(3) else dp(1), if (f) Color.WHITE else 0x33FFFFFF)
        }
        fl.background = bg(false)
        fl.isFocusable = true; fl.isClickable = true
        fl.addView(TextView(this).apply {
            text = t.name; textSize = 13f; setTextColor(Color.WHITE)
            setShadowLayer(3f, 0f, 1f, 0xCC000000.toInt())
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(10); bottomMargin = dp(8) })
        fl.addView(View(this).apply {
            background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(t.accent) }
        }, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.TOP or Gravity.END).apply { topMargin = dp(8); rightMargin = dp(8) })
        fl.setOnFocusChangeListener { v, f ->
            v.background = bg(f)
            v.animate().scaleX(if (f) 1.06f else 1f).scaleY(if (f) 1.06f else 1f).setDuration(110).start()
        }
        fl.setOnClickListener { applyThemePreset(t) }
        return fl
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
